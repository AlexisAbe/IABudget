
import React, { useContext } from 'react';
import { UserContext } from './context/UserContext';
import Onboarding from './components/onboarding/Onboarding';
import MainLayout from './components/layout/MainLayout';

const App: React.FC = () => {
  const context = useContext(UserContext);

  if (!context) {
    return <div>Loading context...</div>;
  }

  const { userProfile, loading } = context;

  if (loading) {
    // This prevents a flash of the Onboarding screen while context is loading from localStorage
    return (
        <div className="flex items-center justify-center h-screen bg-gray-900">
            <div className="text-white text-xl">Chargement de votre cockpit...</div>
        </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {userProfile ? <MainLayout /> : <Onboarding />}
    </div>
  );
};

export default App;
