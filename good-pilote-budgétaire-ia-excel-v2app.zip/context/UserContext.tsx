import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, Transaction, Goal, Persona, Challenge, GoalSuggestion, Investment, UserContextType, BudgetCategory, BudgetPlanItem, Currency, ActionItem, ActionableTransaction } from '../types';

export const UserContext = createContext<UserContextType | undefined>(undefined);

const DEFAULT_BUDGET_CATEGORIES: BudgetCategory[] = [
    // Revenus
    { id: 'default-rev-1', name: 'Salaire & Assimilé', type: 'Revenu' },
    { id: 'default-rev-2', name: 'Revenus Complémentaires', type: 'Revenu' },
    // Dépenses
    { id: 'default-dep-1', name: 'Logement > Loyer / Crédit', type: 'Dépense' },
    { id: 'default-dep-2', name: 'Logement > Assurances', type: 'Dépense' },
    { id: 'default-dep-3', name: 'Énergies > Électricité / Gaz / Eau', type: 'Dépense' },
    { id: 'default-dep-4', name: 'Communication > Internet / Téléphone', type: 'Dépense' },
    { id: 'default-dep-5', name: 'Abonnements > Streaming & Services', type: 'Dépense' },
    { id: 'default-dep-6', name: 'Transports > Pass / Abonnement', type: 'Dépense' },
    { id: 'default-dep-7', name: 'Transports > Carburant / Entretien', type: 'Dépense' },
    { id: 'default-dep-8', name: 'Santé > Mutuelle & Soins', type: 'Dépense' },
    { id: 'default-dep-9', name: 'Remboursements > Crédits', type: 'Dépense' },
    { id: 'default-dep-10', name: 'Alimentation > Courses', type: 'Dépense' },
    { id: 'default-dep-11', name: 'Alimentation > Restaurants / Sorties', type: 'Dépense' },
    { id: 'default-dep-12', name: 'Shopping & Achats', type: 'Dépense' },
    { id: 'default-dep-13', name: 'Loisirs & Vacances', type: 'Dépense' },
    { id: 'default-dep-14', name: 'Enfants', type: 'Dépense' },
    { id: 'default-dep-15', name: 'Autres Dépenses', type: 'Dépense' },
    // Épargne
    { id: 'default-epg-1', name: 'Épargne de Précaution', type: 'Épargne' },
    { id: 'default-epg-2', name: 'Épargne Projet', type: 'Épargne' },
    { id: 'default-epg-3', name: 'Investissements', type: 'Épargne' },
];


export const UserProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [persona, setPersona] = useState<Persona | null>(null);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [budgetCategories, setBudgetCategories] = useState<BudgetCategory[]>([]);
  const [budgetPlan, setBudgetPlan] = useState<BudgetPlanItem[]>([]);
  const [actionItems, setActionItems] = useState<ActionItem[]>([]);
  const [currency, setCurrency] = useState<Currency>('€');


  useEffect(() => {
    try {
      const storedProfile = localStorage.getItem('userProfile');
      const storedTransactions = localStorage.getItem('transactions');
      const storedGoals = localStorage.getItem('goals');
      const storedPersona = localStorage.getItem('persona');
      const storedChallenges = localStorage.getItem('challenges');
      const storedInvestments = localStorage.getItem('investments');
      const storedBudgetCategories = localStorage.getItem('budgetCategories');
      const storedBudgetPlan = localStorage.getItem('budgetPlan');
      const storedActionItems = localStorage.getItem('actionItems');
      const storedCurrency = localStorage.getItem('currency');

      if (storedProfile) setUserProfile(JSON.parse(storedProfile));
      if (storedTransactions) setTransactions(JSON.parse(storedTransactions));
      if (storedGoals) setGoals(JSON.parse(storedGoals));
      if (storedPersona) setPersona(JSON.parse(storedPersona));
      if (storedChallenges) setChallenges(JSON.parse(storedChallenges));
      if (storedInvestments) setInvestments(JSON.parse(storedInvestments));
      if (storedBudgetPlan) setBudgetPlan(JSON.parse(storedBudgetPlan));
      
      if (storedActionItems) {
        const parsedActionItems: any[] = JSON.parse(storedActionItems);
        // Migration logic for old action items
        const migratedActionItems = parsedActionItems.map(item => {
            if (item.relatedTransactionIds && !item.relatedTransactions) {
                return {
                    ...item,
                    relatedTransactions: item.relatedTransactionIds.map((id: string) => ({
                        transactionId: id,
                        status: 'none'
                    })),
                    relatedTransactionIds: undefined // remove old key
                };
            }
            return item;
        });
        setActionItems(migratedActionItems);
      }
      
      if (storedCurrency) setCurrency(JSON.parse(storedCurrency));

      // Set default categories if none exist
      if (storedBudgetCategories) {
          setBudgetCategories(JSON.parse(storedBudgetCategories));
      } else {
          const legacyCustomCategories = localStorage.getItem('customCategories');
          if (legacyCustomCategories) { // Migration from old format
              const oldCategories: string[] = JSON.parse(legacyCustomCategories);
              const newBudgetCategories: BudgetCategory[] = oldCategories.map((name, index) => ({
                  id: `migrated-${Date.now()}-${index}`,
                  name: name,
                  type: 'Dépense'
              }));
              setBudgetCategories(newBudgetCategories);
              localStorage.setItem('budgetCategories', JSON.stringify(newBudgetCategories));
              localStorage.removeItem('customCategories');
          } else { // Fresh start, load defaults
              setBudgetCategories(DEFAULT_BUDGET_CATEGORIES);
              localStorage.setItem('budgetCategories', JSON.stringify(DEFAULT_BUDGET_CATEGORIES));
          }
      }

    } catch (error) {
      console.error("Failed to parse from localStorage", error);
    } finally {
        setLoading(false);
    }
  }, []);

  const saveStateToLocalStorage = <T,>(key: string, state: T) => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch (error) {
      console.error(`Failed to save ${key} to localStorage`, error);
    }
  };

  const saveUserProfile = (profile: Omit<UserProfile, 'currency'>, personaData: Persona) => {
    const newProfile: UserProfile = { ...profile, currency: '€' }; // Default currency
    setUserProfile(newProfile);
    setPersona(personaData);
    saveStateToLocalStorage('userProfile', newProfile);
    saveStateToLocalStorage('persona', personaData);
  };

  const handleSetTransactions = (newTransactions: Transaction[]) => {
    setTransactions(newTransactions);
    saveStateToLocalStorage('transactions', newTransactions);
  };

  const addSupplementaryTransactions = (supplementaryTransactions: Transaction[], transactionToReplaceId: string) => {
    const updatedTransactions = [
        ...transactions.filter(t => t.id !== transactionToReplaceId),
        ...supplementaryTransactions
    ];
    setTransactions(updatedTransactions);
    saveStateToLocalStorage('transactions', updatedTransactions);
  };

  const updateTransaction = (updatedTransaction: Transaction) => {
    const updatedTransactions = transactions.map(t => t.id === updatedTransaction.id ? updatedTransaction : t);
    setTransactions(updatedTransactions);
    saveStateToLocalStorage('transactions', updatedTransactions);
  };
  
  const addGoal = (goal: Omit<Goal, 'id' | 'currentAmount' | 'suggestions'>) => {
    const newGoal: Goal = { ...goal, id: Date.now().toString(), currentAmount: 0, suggestions: [] };
    const updatedGoals = [...goals, newGoal];
    setGoals(updatedGoals);
    saveStateToLocalStorage('goals', updatedGoals);
  };

  const updateGoal = (updatedGoal: Goal) => {
    const updatedGoals = goals.map(g => g.id === updatedGoal.id ? updatedGoal : g);
    setGoals(updatedGoals);
    saveStateToLocalStorage('goals', updatedGoals);
  };

  const deleteGoal = (goalId: string) => {
    const updatedGoals = goals.filter(g => g.id !== goalId);
    setGoals(updatedGoals);
    saveStateToLocalStorage('goals', updatedGoals);
  };

  const addSuggestionsToGoal = (goalId: string, suggestions: GoalSuggestion[]) => {
    const updatedGoals = goals.map(g => {
        if (g.id === goalId) {
            return { ...g, suggestions: suggestions.map(s => ({...s, completed: false})) };
        }
        return g;
    });
    setGoals(updatedGoals);
    saveStateToLocalStorage('goals', updatedGoals);
  };

  const toggleSuggestionCompleted = (goalId: string, suggestionId: string) => {
      const updatedGoals = goals.map(g => {
          if (g.id === goalId) {
              let newCurrentAmount = g.currentAmount;
              const newSuggestions = g.suggestions?.map(s => {
                  if (s.id === suggestionId) {
                      newCurrentAmount += !s.completed ? s.potentialSaving : -s.potentialSaving;
                      return { ...s, completed: !s.completed };
                  }
                  return s;
              });
              return { ...g, suggestions: newSuggestions, currentAmount: newCurrentAmount };
          }
          return g;
      });
      setGoals(updatedGoals);
      saveStateToLocalStorage('goals', updatedGoals);
  };

  const handleSetChallenges = (newChallenges: Challenge[]) => {
    setChallenges(newChallenges);
    saveStateToLocalStorage('challenges', newChallenges);
  };
  
  const handleSetInvestments = (newInvestments: Investment[]) => {
      setInvestments(newInvestments);
      saveStateToLocalStorage('investments', newInvestments);
  };

  const handleAddBudgetCategory = (category: Omit<BudgetCategory, 'id'>) => {
      const newCategory = { ...category, id: `cat-${Date.now()}`};
      if (!budgetCategories.some(c => c.name.toLowerCase() === newCategory.name.toLowerCase())) {
          const newCategories = [...budgetCategories, newCategory];
          setBudgetCategories(newCategories);
          saveStateToLocalStorage('budgetCategories', newCategories);
      }
  }

  const handleUpdateBudgetCategory = (category: BudgetCategory) => {
    const newCategories = budgetCategories.map(c => c.id === category.id ? category : c);
    setBudgetCategories(newCategories);
    saveStateToLocalStorage('budgetCategories', newCategories);
  }

  const handleDeleteBudgetCategory = (categoryId: string) => {
    const newCategories = budgetCategories.filter(c => c.id !== categoryId);
    setBudgetCategories(newCategories);
    saveStateToLocalStorage('budgetCategories', newCategories);
    // Also remove from budget plan
    const newPlan = budgetPlan.filter(p => p.categoryId !== categoryId);
    setBudgetPlan(newPlan);
    saveStateToLocalStorage('budgetPlan', newPlan);
  }
  
  const handleSetBudgetCategories = (categories: BudgetCategory[]) => {
      setBudgetCategories(categories);
      saveStateToLocalStorage('budgetCategories', categories);
  }

  const handleSetBudgetPlan = (plan: BudgetPlanItem[]) => {
      setBudgetPlan(plan);
      saveStateToLocalStorage('budgetPlan', plan);
  }

  const handleUpdateBudgetPlanItem = (item: BudgetPlanItem) => {
    const newPlan = [...budgetPlan];
    const index = newPlan.findIndex(p => p.categoryId === item.categoryId && p.month === item.month && p.year === item.year);
    const updatedItem = { ...item, isProjected: false }; // When user updates, it's no longer a projection.

    if(index > -1) {
        newPlan[index] = updatedItem;
    } else {
        newPlan.push(updatedItem);
    }
    setBudgetPlan(newPlan);
    saveStateToLocalStorage('budgetPlan', newPlan);
  };
  
  const handleSetCurrency = (newCurrency: Currency) => {
      setCurrency(newCurrency);
      saveStateToLocalStorage('currency', newCurrency);
      if(userProfile) {
          const updatedProfile = {...userProfile, currency: newCurrency };
          setUserProfile(updatedProfile);
          saveStateToLocalStorage('userProfile', updatedProfile);
      }
  }

  const handleAddActionItem = (item: Omit<ActionItem, 'id' | 'status'>) => {
    const newActionItem: ActionItem = {
      ...item,
      id: `action-${Date.now()}`,
      status: 'todo',
    };
    const updatedItems = [...actionItems, newActionItem];
    setActionItems(updatedItems);
    saveStateToLocalStorage('actionItems', updatedItems);
  };

  const handleUpdateActionItem = (itemId: string, updates: Partial<Pick<ActionItem, 'status'>>) => {
    const updatedItems = actionItems.map(item =>
      item.id === itemId ? { ...item, ...updates } : item
    );
    setActionItems(updatedItems);
    saveStateToLocalStorage('actionItems', updatedItems);
  };

  const handleDeleteActionItem = (itemId: string) => {
    const updatedItems = actionItems.filter(item => item.id !== itemId);
    setActionItems(updatedItems);
    saveStateToLocalStorage('actionItems', updatedItems);
  };

  const handleUpdateActionableTransactionStatus = (actionItemId: string, transactionId: string, status: ActionableTransaction['status']) => {
    const updatedItems = actionItems.map(item => {
      if (item.id === actionItemId) {
        const newRelatedTransactions = item.relatedTransactions.map(rt => 
          rt.transactionId === transactionId ? { ...rt, status } : rt
        );
        return { ...item, relatedTransactions: newRelatedTransactions };
      }
      return item;
    });
    setActionItems(updatedItems);
    saveStateToLocalStorage('actionItems', updatedItems);
  };

  const resetApp = () => {
    localStorage.clear();
    setUserProfile(null);
    setTransactions([]);
    setGoals([]);
    setPersona(null);
    setChallenges([]);
    setInvestments([]);
    setBudgetCategories([]);
    setBudgetPlan([]);
    setActionItems([]);
    setCurrency('€');
    window.location.reload();
  };

  return (
    <UserContext.Provider value={{ 
      userProfile, 
      transactions, 
      goals, 
      persona, 
      challenges,
      investments,
      budgetCategories,
      budgetPlan,
      actionItems,
      currency,
      loading,
      saveUserProfile, 
      setTransactions: handleSetTransactions, 
      addSupplementaryTransactions,
      updateTransaction,
      addGoal, 
      updateGoal,
      deleteGoal,
      setChallenges: handleSetChallenges,
      addSuggestionsToGoal,
      toggleSuggestionCompleted,
      setInvestments: handleSetInvestments,
      addBudgetCategory: handleAddBudgetCategory,
      updateBudgetCategory: handleUpdateBudgetCategory,
      deleteBudgetCategory: handleDeleteBudgetCategory,
      setBudgetCategories: handleSetBudgetCategories,
      setBudgetPlan: handleSetBudgetPlan,
      updateBudgetPlanItem: handleUpdateBudgetPlanItem,
      addActionItem: handleAddActionItem,
      updateActionItem: handleUpdateActionItem,
      updateActionableTransactionStatus: handleUpdateActionableTransactionStatus,
      deleteActionItem: handleDeleteActionItem,
      setCurrency: handleSetCurrency,
      resetApp
    }}>
      {children}
    </UserContext.Provider>
  );
};