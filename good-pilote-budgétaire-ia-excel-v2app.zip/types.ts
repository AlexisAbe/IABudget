export type Currency = '€' | '$' | '£' | '¥';

export type BudgetCategoryType = 'Revenu' | 'Dépense' | 'Épargne';

export interface BudgetCategory {
    id: string;
    name: string;
    type: BudgetCategoryType;
}

export interface BudgetPlanItem {
    categoryId: string;
    month: number; // 1-12
    year: number;
    plannedAmount: number;
    isProjected?: boolean;
}

export interface UserProfile {
  name: string;
  onboarded: boolean;
  currency: Currency;
}

export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'debit' | 'credit';
  category?: string;
  isRecurring?: boolean;
}

export interface GoalSuggestion {
    id: string;
    description: string;
    potentialSaving: number; // in euros
    completed: boolean;
}

export interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  emoji: string;
  deadline?: string;
  suggestions?: GoalSuggestion[];
}

export interface Persona {
  title: string;
  description: string;
  adjectives: string[];
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  emoji: string;
  reward: number; // e.g. potential savings
}

export interface Investment {
    id: string;
    name: string;
    type: 'Fonds d\'urgence' | 'Épargne long terme' | 'Autre';
    amount: number;
}

export interface SpendingHabitAnalysis {
    id: string;
    category: string;
    description: string;
    suggestion: string;
    amount: number;
    potentialSaving: number;
}

export interface ActionableTransaction {
  transactionId: string;
  status: 'none' | 'reduce' | 'eliminate' | 'challenge';
}

export interface ActionItem {
    id: string;
    title: string;
    description: string;
    potentialSaving: number;
    relatedTransactions: ActionableTransaction[];
    status: 'todo' | 'done';
    actionType: 'reduce' | 'eliminate' | 'monitor';
}


export enum AppView {
    Cockpit = 'COCKPIT',
    Transactions = 'TRANSACTIONS',
    Goals = 'GOALS',
    Categories = 'CATEGORIES',
    Budget = 'BUDGET',
    ActionPlan = 'ACTION_PLAN',
}

export enum BudgetView {
    Home = 'HOME',
    Monthly = 'MONTHLY',
    Annual = 'ANNUAL',
    Comparison = 'COMPARISON',
    Planner = 'PLANNER',
    Transactions = 'TRANSACTIONS',
    BudgetCategories = 'BUDGET_CATEGORIES',
}

export interface UserContextType {
  userProfile: UserProfile | null;
  transactions: Transaction[];
  goals: Goal[];
  persona: Persona | null;
  challenges: Challenge[];
  investments: Investment[];
  budgetCategories: BudgetCategory[];
  budgetPlan: BudgetPlanItem[];
  actionItems: ActionItem[];
  currency: Currency;
  loading: boolean;
  saveUserProfile: (profile: Omit<UserProfile, 'currency'>, persona: Persona) => void;
  setTransactions: (transactions: Transaction[]) => void;
  addSupplementaryTransactions: (supplementaryTransactions: Transaction[], transactionToReplaceId: string) => void;
  updateTransaction: (updatedTransaction: Transaction) => void;
  addGoal: (goal: Omit<Goal, 'id' | 'currentAmount' | 'suggestions'>) => void;
  updateGoal: (goal: Goal) => void;
  deleteGoal: (goalId: string) => void;
  setChallenges: (challenges: Challenge[]) => void;
  addSuggestionsToGoal: (goalId: string, suggestions: GoalSuggestion[]) => void;
  toggleSuggestionCompleted: (goalId: string, suggestionId: string) => void;
  setInvestments: (investments: Investment[]) => void;
  addBudgetCategory: (category: Omit<BudgetCategory, 'id'>) => void;
  updateBudgetCategory: (category: BudgetCategory) => void;
  deleteBudgetCategory: (categoryId: string) => void;
  setBudgetCategories: (categories: BudgetCategory[]) => void;
  setBudgetPlan: (plan: BudgetPlanItem[]) => void;
  updateBudgetPlanItem: (item: BudgetPlanItem) => void;
  addActionItem: (item: Omit<ActionItem, 'id' | 'status'>) => void;
  updateActionItem: (itemId: string, updates: Partial<Pick<ActionItem, 'status'>>) => void;
  updateActionableTransactionStatus: (actionItemId: string, transactionId: string, status: ActionableTransaction['status']) => void;
  deleteActionItem: (itemId: string) => void;
  setCurrency: (currency: Currency) => void;
  resetApp: () => void;
}