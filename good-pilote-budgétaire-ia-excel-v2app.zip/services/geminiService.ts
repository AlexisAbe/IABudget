import { GoogleGenAI, Type } from "@google/genai";
import { Persona, Challenge, Transaction, Goal, GoalSuggestion, Investment, SpendingHabitAnalysis, BudgetCategory } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. Using mocked responses.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

// Schemas...

const personaSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "Un titre accrocheur pour le persona, comme 'L'Architecte Prudent' ou 'L'Aventurier Économe'." },
    description: { type: Type.STRING, description: "Une courte description de la stratégie financière de l'utilisateur." },
    adjectives: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Trois adjectifs qui décrivent le mieux l'approche financière de l'utilisateur."
    },
  },
  required: ["title", "description", "adjectives"],
};

const challengesSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        id: { type: Type.STRING, description: "Un identifiant unique pour le défi, ex: 'cafe-challenge-1'" },
        title: { type: Type.STRING, description: "Un titre court et motivant pour le défi." },
        description: { type: Type.STRING, description: "Une description claire de ce que l'utilisateur doit faire." },
        emoji: { type: Type.STRING, description: "Un seul emoji pour représenter le défi." },
        reward: { type: Type.INTEGER, description: "L'économie potentielle en euros réalisable avec ce défi." },
      },
      required: ["id", "title", "description", "emoji", "reward"],
    }
};

const transactionsSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            id: { type: Type.STRING },
            date: { type: Type.STRING },
            description: { type: Type.STRING },
            amount: { type: Type.NUMBER },
            type: { type: Type.STRING, enum: ['debit', 'credit']},
            category: { type: Type.STRING, description: "Catégorie de la dépense (ex: 'Courses', 'Restaurant', 'Transport', 'Loyer', 'Salaire')." },
            isRecurring: { type: Type.BOOLEAN, description: "Vrai si la transaction semble récurrente (loyer, abonnement)." },
        },
        required: ["id", "date", "description", "amount", "type", "category", "isRecurring"],
    }
};

const goalSuggestionsSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            id: { type: Type.STRING, description: "Identifiant unique pour la suggestion, ex: 'sugg-resto-1'" },
            description: { type: Type.STRING, description: "Description de la micro-action à réaliser pour économiser." },
            potentialSaving: { type: Type.NUMBER, description: "Estimation de l'économie réalisable en euros." },
        },
        required: ["id", "description", "potentialSaving"]
    }
};

const spendingHabitsSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            id: { type: Type.STRING, description: "Un identifiant unique pour l'analyse, ex: 'habit-1'" },
            category: { type: Type.STRING, description: "La catégorie de dépense principale concernée." },
            amount: { type: Type.NUMBER, description: "Le montant total de cette dépense sur la période." },
            description: { type: Type.STRING, description: "Une description de l'habitude de dépense identifiée (ex: 'Dépenses fréquentes dans les fast-foods')." },
            suggestion: { type: Type.STRING, description: "Une suggestion concrète pour réduire ou optimiser cette dépense (ex: 'Essayez de remplacer 2 repas rapides par des repas maison par semaine pour économiser X€')." },
            potentialSaving: { type: Type.NUMBER, description: "Le montant chiffré de l'économie potentielle suggérée en euros."}
        },
        required: ["id", "category", "amount", "description", "suggestion", "potentialSaving"]
    }
};

const relevantTransactionsSchema = {
    type: Type.OBJECT,
    properties: {
        transactionIds: {
            type: Type.ARRAY,
            description: "Une liste des identifiants (id) des transactions les plus pertinentes pour l'analyse.",
            items: { type: Type.STRING }
        }
    },
    required: ["transactionIds"]
};


const categoryMappingSchema = {
    type: Type.OBJECT,
    properties: {
        mapping: {
            type: Type.ARRAY,
            description: "An array of mapping objects from transaction categories to budget categories.",
            items: {
                type: Type.OBJECT,
                properties: {
                    transactionCategory: { type: Type.STRING, description: "The category found in the transaction data." },
                    budgetCategory: { type: Type.STRING, nullable: true, description: "The most appropriate budget category from the provided list, or null if no good match is found." }
                },
                required: ["transactionCategory", "budgetCategory"]
            }
        }
    },
    required: ["mapping"]
};

const prefillAnalysisSchema = {
    type: Type.OBJECT,
    properties: {
        salary: {
            type: Type.OBJECT,
            description: "Analyse du salaire mensuel de l'utilisateur.",
            properties: {
                amount: { type: Type.NUMBER, description: "Le montant mensuel estimé du salaire principal." },
            },
            required: ["amount"]
        },
        rent: {
            type: Type.OBJECT,
            description: "Analyse du loyer/crédit mensuel de l'utilisateur.",
            properties: {
                amount: { type: Type.NUMBER, description: "Le montant mensuel estimé du loyer ou du crédit immobilier." },
            },
            required: ["amount"]
        },
        questions: {
            type: Type.ARRAY,
            description: "Liste de 2-3 questions pour clarifier d'autres postes budgétaires importants ou variables.",
            items: {
                type: Type.OBJECT,
                properties: {
                    categoryName: { type: Type.STRING, description: "Le nom exact de la catégorie de budget concernée." },
                    question: { type: Type.STRING, description: "La question à poser à l'utilisateur." },
                    suggestedAmount: { type: Type.NUMBER, description: "Le montant moyen mensuel calculé par l'IA pour ce poste." }
                },
                required: ["categoryName", "question", "suggestedAmount"]
            }
        }
    },
    required: ["salary", "rent", "questions"]
};

// Functions...

export const createFinancialPersona = async (userInfo: string, investments: Investment[]): Promise<Persona> => {
    if (!API_KEY) {
        console.log("MOCK: createFinancialPersona");
        await new Promise(res => setTimeout(res, 1500));
        return {
            title: "L'Architecte Prudent",
            description: "Vous construisez votre avenir financier brique par brique, avec une attention particulière à la sécurité et à la croissance à long terme.",
            adjectives: ["Organisé", "Visionnaire", "Sécuritaire"]
        };
    }
    
    const investmentInfo = investments.length > 0
        ? `Placements actuels: ${investments.map(i => `${i.name} (${i.type}): ${i.amount}€`).join(', ')}.`
        : "Aucun placement renseigné.";

    const prompt = `Basé sur ces informations utilisateur : "${userInfo}". ${investmentInfo}. Crée un persona financier inspirant. Le ton doit être positif et encourageant.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: personaSchema
        }
    });

    const json = JSON.parse(response.text);
    return json as Persona;
};

export const analyzeTransactionsFromFile = async (fileBase64: string, mimeType: string): Promise<Transaction[]> => {
    if (!API_KEY) {
        console.log("MOCK: analyzeTransactionsFromFile");
        await new Promise(res => setTimeout(res, 2000));
        return [
            { id: 'tx-mock-1', date: '2023-10-26T00:00:00.000Z', description: 'Courses Super U', amount: 52.30, type: 'debit', category: 'Courses', isRecurring: false },
            { id: 'tx-mock-2', date: '2023-10-25T00:00:00.000Z', description: 'Salaire Octobre', amount: 2500.00, type: 'credit', category: 'Salaire', isRecurring: true },
            { id: 'tx-mock-3', date: '2023-10-24T00:00:00.000Z', description: 'Abonnement Netflix', amount: 13.49, type: 'debit', category: 'Abonnements', isRecurring: true },
            { id: 'tx-mock-4', date: '2023-10-22T00:00:00.000Z', description: 'Restaurant Le Bistrot', amount: 35.50, type: 'debit', category: 'Restaurant', isRecurring: false },
            { id: 'tx-mock-5', date: '2023-10-20T00:00:00.000Z', description: 'Virement Loyer', amount: 750.00, type: 'debit', category: 'Loyer', isRecurring: true },
            { id: 'tx-mock-6', date: '2023-10-20T00:00:00.000Z', description: 'Cinéma UGC', amount: 25.00, type: 'debit', category: 'Loisirs > Cinéma', isRecurring: false },
        ];
    }

    const filePart = {
        inlineData: {
          data: fileBase64,
          mimeType: mimeType,
        },
    };

    const textPart = {
        text: `Analyse ce fichier de transactions (CSV ou PDF). Extrais les transactions. Pour chaque transaction, assigne un 'id' unique (ex: 'tx-123'), la 'date' (format ISO 8601), la 'description', le 'amount' (nombre positif), le 'type' ('debit' ou 'credit'), une 'category' pertinente (ex: 'Courses', 'Restaurant', 'Loyer', 'Salaire'). Si une catégorie a une sous-catégorie évidente, utilise le format 'Catégorie > Sous-catégorie' (ex: 'Loisirs > Cinéma'). Enfin, un booléen 'isRecurring' si la transaction est récurrente. Ignore les en-têtes/lignes non pertinents. Retourne un tableau JSON valide.`,
    };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [filePart, textPart] },
        config: {
            responseMimeType: 'application/json',
            responseSchema: transactionsSchema
        }
    });
    
    const json = JSON.parse(response.text);
    return json as Transaction[];
};


export const generateChallenges = async (persona: Persona, transactions: Transaction[]): Promise<Challenge[]> => {
    if (!API_KEY) {
        console.log("MOCK: generateChallenges");
        await new Promise(res => setTimeout(res, 1000));
        return [
            { id: '1', title: "Mission Café", description: "Préparez votre café à la maison cette semaine et économisez sur les cafés à emporter.", emoji: "☕", reward: 15 },
            { id: '2', title: "Défi 'Fait Maison'", description: "Cuisinez 3 repas de plus que d'habitude cette semaine au lieu de commander.", emoji: "🧑‍🍳", reward: 40 },
            { id: '3', title: "Audit d'abonnements", description: "Passez en revue vos abonnements mensuels et annulez-en un que vous n'utilisez plus.", emoji: "📜", reward: 20 },
        ];
    }
    
    const transactionsSample = transactions.slice(0, 20).map(t => `${t.description}: ${t.amount}€`).join(', ');

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Je suis un utilisateur avec le persona financier : "${persona.title} - ${persona.description}". Voici un aperçu de mes récentes dépenses : ${transactionsSample}. Propose-moi 3 défis financiers courts, concrets et personnalisés pour le mois à venir, en te basant sur mon profil et mes dépenses.`,
        config: {
            responseMimeType: 'application/json',
            responseSchema: challengesSchema
        }
    });

    const json = JSON.parse(response.text);
    return json as Challenge[];
};

export const generateOptimizationPlan = async (goal: Goal, transactions: Transaction[], monthlyShortfall: number, investments: Investment[]): Promise<Omit<GoalSuggestion, 'completed'>[]> => {
    if (!API_KEY) {
        console.log("MOCK: generateOptimizationPlan");
        await new Promise(res => setTimeout(res, 1500));
        return [
            { id: 'sugg-1', description: `Réduire les dépenses "Restaurant" de 45€/mois.`, potentialSaving: 45 },
            { id: 'sugg-2', description: `Suspendre l'abonnement "Fitness" non utilisé.`, potentialSaving: 30 },
            { id: 'sugg-3', description: `Allouer 50€ de plus à l'épargne depuis la catégorie "Loisirs".`, potentialSaving: 50 },
        ];
    }

    const transactionsSample = transactions
        .filter(t => t.type === 'debit')
        .slice(0, 20)
        .map(t => `${t.category || 'Non classé'}: ${t.amount}€`)
        .join('; ');
        
    const investmentInfo = investments.length > 0
        ? `L'utilisateur possède déjà ces placements: ${investments.map(i => `${i.name} (${i.type}): ${i.amount}€`).join(', ')}.`
        : "L'utilisateur n'a pas renseigné de placements.";

    const prompt = `L'objectif de l'utilisateur est : "${goal.name}" (${goal.targetAmount}€ avant le ${goal.deadline}). Il lui manque ${monthlyShortfall.toFixed(2)}€/mois pour l'atteindre. Voici un aperçu de ses dépenses : ${transactionsSample}. ${investmentInfo} Génère un plan d'optimisation avec des actions concrètes et chiffrées pour l'aider à économiser ce montant. Cible des catégories de dépenses spécifiques et propose des réductions réalistes. Prends en compte son patrimoine existant pour la pertinence des conseils.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: goalSuggestionsSchema
        }
    });

    const json = JSON.parse(response.text);
    return json;
};

export const analyzeSpendingHabits = async (transactions: Transaction[]): Promise<SpendingHabitAnalysis[]> => {
    if (!API_KEY) {
        console.log("MOCK: analyzeSpendingHabits");
        await new Promise(res => setTimeout(res, 1500));
        return [
            { id: 'habit-1', category: 'Restaurant', amount: 150.75, description: 'Dépenses fréquentes dans les fast-foods et restaurants.', suggestion: 'Essayez de remplacer 2 repas au restaurant par des repas faits maison pour économiser environ 50€.', potentialSaving: 50 },
            { id: 'habit-2', category: 'Abonnements', amount: 49.99, description: 'Multiples abonnements à des services de streaming.', suggestion: 'Partagez un compte avec un ami ou faites une pause sur un service que vous utilisez peu pour économiser 15€/mois.', potentialSaving: 15 },
            { id: 'habit-3', category: 'Shopping', amount: 210.50, description: 'Achats impulsifs en ligne.', suggestion: 'Instaurez une règle d\'attente de 48h avant tout achat non essentiel de plus de 30€.', potentialSaving: 30 }
        ];
    }

    const debitTransactions = transactions.filter(t => t.type === 'debit' && t.category);
    if (debitTransactions.length === 0) {
        return [];
    }

    const transactionsSummary = debitTransactions
        .map(t => `${t.category}: ${t.amount.toFixed(2)}€`)
        .join('; ');

    const prompt = `En te basant sur la liste de transactions suivante pour une période donnée: "${transactionsSummary}", agis comme un conseiller financier expert. Identifie 3 à 5 habitudes de dépenses "moins optimales" ou non essentielles. Pour chaque habitude, fournis une analyse, une suggestion d'amélioration concrète, le montant de l'économie potentielle ('potentialSaving'), et une description. L'objectif est d'aider l'utilisateur à économiser. Sois concis et direct.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: spendingHabitsSchema
        }
    });

    const json = JSON.parse(response.text);
    return json as SpendingHabitAnalysis[];
};

export const findRelevantTransactions = async (
    transactions: Transaction[],
    insightTitle: string,
    insightDescription: string
): Promise<string[]> => {
    if (!API_KEY) {
        console.log("MOCK: findRelevantTransactions");
        await new Promise(res => setTimeout(res, 800));
        // Simple mock logic
        const keywords = insightTitle.toLowerCase().split(' ');
        return transactions
            .filter(t => keywords.some(k => t.description.toLowerCase().includes(k) || (t.category && t.category.toLowerCase().includes(k))))
            .slice(0, 5) // Return up to 5 mock transactions
            .map(t => t.id);
    }

    const transactionSummary = transactions.map(t => `id: ${t.id}, date: ${t.date}, description: ${t.description}, category: ${t.category || 'N/A'}, amount: ${t.amount}`).join('\n');
    
    const prompt = `Voici une analyse financière :
    - Titre : "${insightTitle}"
    - Description : "${insightDescription}"

    Et voici une liste de transactions :
    ${transactionSummary}

    En te basant sur le titre et la description de l'analyse, identifie les 5 à 10 transactions les plus pertinentes dans la liste fournie qui justifient cette analyse. Retourne uniquement les identifiants ('id') de ces transactions.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: relevantTransactionsSchema,
        }
    });

    const json = JSON.parse(response.text);
    return json.transactionIds || [];
};

export const mapTransactionCategoriesToBudget = async (
    transactionCategories: string[],
    budgetCategories: BudgetCategory[]
): Promise<Record<string, string | null>> => {
    if (!API_KEY) {
        console.log("MOCK: mapTransactionCategoriesToBudget");
        await new Promise(res => setTimeout(res, 1000));
        const mapping: Record<string, string | null> = {};
        transactionCategories.forEach(tCat => {
            const tCatLower = tCat.toLowerCase().split(' > ')[0];
            const found = budgetCategories.find(bCat =>
                bCat.name.toLowerCase().includes(tCatLower)
            );
            mapping[tCat] = found ? found.name : null;
        });
        // Add a specific mock for common cases
        if (mapping['Loyer']) mapping['Loyer'] = 'Logement > Loyer / Crédit';
        if (mapping['Salaire']) mapping['Salaire'] = 'Salaire & Assimilé';
        return mapping;
    }

    const budgetCategoryNames = budgetCategories.map(c => c.name);
    const prompt = `Fais correspondre sémantiquement chaque 'catégorie de transaction' à la 'catégorie de budget' la plus appropriée.
    - Catégories de budget disponibles: ${JSON.stringify(budgetCategoryNames)}
    - Catégories de transaction à mapper: ${JSON.stringify(transactionCategories)}
    
    Règles:
    1.  Chaque catégorie de transaction DOIT être mappée.
    2.  Le résultat doit être une catégorie de budget EXACTE de la liste, ou null si aucune correspondance n'est évidente.
    3.  Privilégie la correspondance la plus logique (ex: "Restaurant" va dans "Alimentation > Restaurants / Sorties").`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: categoryMappingSchema,
        }
    });

    const jsonResponse = JSON.parse(response.text);
    const resultMap: Record<string, string | null> = {};
    if (jsonResponse.mapping && Array.isArray(jsonResponse.mapping)) {
        for (const item of jsonResponse.mapping) {
            resultMap[item.transactionCategory] = item.budgetCategory;
        }
    }
    return resultMap;
};

export interface PrefillAnalysisResult {
    salary: { amount: number };
    rent: { amount: number };
    questions: {
        categoryName: string;
        question: string;
        suggestedAmount: number;
    }[];
}

export const analyzeForBudgetPreFill = async (transactions: Transaction[], budgetCategories: BudgetCategory[]): Promise<PrefillAnalysisResult> => {
     if (!API_KEY) {
        console.log("MOCK: analyzeForBudgetPreFill");
        await new Promise(res => setTimeout(res, 1000));
        return {
            salary: { amount: 2500 },
            rent: { amount: 750 },
            questions: [
                { categoryName: 'Alimentation > Courses', question: 'Vos dépenses en courses varient. Quel budget mensuel souhaitez-vous allouer ?', suggestedAmount: 420 },
                { categoryName: 'Énergies > Électricité / Gaz / Eau', question: 'Vos factures d\'énergie semblent fluctuer. Quel montant mensuel prévoir ?', suggestedAmount: 85 }
            ]
        };
    }
    
    const transactionsSummary = transactions
        .slice(0, 200) // Limit sample size
        .map(t => `${t.date} | ${t.description} | ${t.amount}€ | ${t.type} | ${t.category || ''}`)
        .join('\n');
    
    const budgetCategoryNames = budgetCategories.map(c => c.name);
    
    const prompt = `Agis comme un analyste financier. Voici un extrait des transactions d'un utilisateur:\n${transactionsSummary}\n\nEt voici ses catégories de budget disponibles:\n${JSON.stringify(budgetCategoryNames)}\n\nTon travail est de préparer une pré-analyse pour un budget annuel. Suis ces étapes:\n1. Identifie le revenu mensuel principal le plus probable (salaire) et estime son montant.\n2. Identifie la dépense de logement principale et récurrente (loyer ou crédit) et estime son montant mensuel.\n3. Choisis 2 ou 3 autres catégories de DÉPENSES importantes et variables (comme les courses, l'énergie, les loisirs). Pour chacune, formule une question claire à l'utilisateur pour l'aider à définir un budget mensuel, et suggère un montant basé sur la moyenne des transactions.\n\nRéponds UNIQUEMENT avec un objet JSON valide qui respecte le schéma fourni.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: prefillAnalysisSchema,
        }
    });

    const json = JSON.parse(response.text);
    return json as PrefillAnalysisResult;
};