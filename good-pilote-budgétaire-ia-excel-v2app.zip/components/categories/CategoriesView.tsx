import React, { useContext, useMemo, useState, FormEvent } from 'react';
import { UserContext } from '../../context/UserContext';
import { PieChartIcon, PlusCircleIcon, ChevronRightIcon } from '../icons';
import { Transaction, BudgetCategory, BudgetCategoryType } from '../../types';

interface CategoryNode {
    name: string;
    total: number;
    transactionCount: number;
    transactions: Transaction[];
    subCategories: { [key: string]: CategoryNode };
}

const buildCategoryTree = (transactions: Transaction[], budgetCategories: BudgetCategory[]): CategoryNode[] => {
    const root: { [key: string]: CategoryNode } = {};

    const allCategoryNames = new Set(budgetCategories.map(c => c.name));
    transactions.forEach(t => {
        if (t.category) allCategoryNames.add(t.category);
    });

    allCategoryNames.forEach(catName => {
        const parts = catName.split('>').map(p => p.trim());
        let currentLevel = root;
        parts.forEach(part => {
            if (!currentLevel[part]) {
                currentLevel[part] = {
                    name: part,
                    total: 0,
                    transactionCount: 0,
                    transactions: [],
                    subCategories: {},
                };
            }
            currentLevel = currentLevel[part].subCategories;
        });
    });

    const assignToTree = (parts: string[], transaction: Transaction) => {
        let currentLevel = root;
        for (let i = 0; i < parts.length; i++) {
            const part = parts[i];
            const node = currentLevel[part];
            if (node) {
                node.total += transaction.amount;
                // Only add transaction to the final node in the path
                if (i === parts.length - 1) {
                    node.transactionCount++;
                    node.transactions.push(transaction);
                }
                currentLevel = node.subCategories;
            } else {
                // This case should ideally not be hit if all categories are pre-populated
                break;
            }
        }
    };
    
    transactions.forEach(t => {
        if (!t.category || t.type !== 'debit') return;
        const parts = t.category.split('>').map(p => p.trim());
        assignToTree(parts, t);
    });

    return Object.values(root);
};


const TransactionRow: React.FC<{ transaction: Transaction }> = ({ transaction }) => (
    <div className="flex justify-between items-center py-2 border-b border-gray-700/50">
        <div>
            <p className="font-medium text-white">{transaction.description}</p>
            <p className="text-sm text-gray-400">{new Date(transaction.date).toLocaleDateString()}</p>
        </div>
        <p className="font-mono text-red-400">-{transaction.amount.toFixed(2)}€</p>
    </div>
);

const CategoryCard: React.FC<{ node: CategoryNode, onSelect: () => void }> = ({ node, onSelect }) => {
    const hasSubcategories = Object.keys(node.subCategories).length > 0;
    return (
        <div onClick={onSelect} className="bg-gray-800 p-4 rounded-xl shadow-lg cursor-pointer hover:bg-gray-700/50 transition-colors duration-200">
            <div className="flex justify-between items-center">
                <div className="flex-grow">
                    <p className="font-bold text-white text-lg">{node.name}</p>
                    <p className="text-sm text-gray-400">{node.transactionCount} transaction{node.transactionCount > 1 ? 's' : ''}</p>
                </div>
                <div className="text-right">
                    <p className="text-xl font-semibold text-indigo-400">{node.total.toFixed(2)}€</p>
                    {hasSubcategories && <span className="text-xs text-gray-500">Contient des sous-catégories</span>}
                </div>
                 <ChevronRightIcon className="w-6 h-6 text-gray-500 ml-3" />
            </div>
        </div>
    );
};

const CategoriesView: React.FC = () => {
    const context = useContext(UserContext);
    const [newCategoryName, setNewCategoryName] = useState('');
    const [newCategoryType, setNewCategoryType] = useState<BudgetCategoryType>('Dépense');
    const [selectedNode, setSelectedNode] = useState<CategoryNode | null>(null);

    const categoryTree = useMemo(() => {
        if (!context) return [];
        return buildCategoryTree(context.transactions, context.budgetCategories);
    }, [context?.transactions, context?.budgetCategories]);

    if (!context) return null;

    const handleAddCategory = (e: FormEvent) => {
        e.preventDefault();
        if (newCategoryName.trim()) {
            context.addBudgetCategory({
                name: newCategoryName.trim(),
                type: newCategoryType,
            });
            setNewCategoryName('');
        }
    };
    
    if (selectedNode) {
        const subCategories = Object.values(selectedNode.subCategories);
        return (
            <div>
                <button onClick={() => setSelectedNode(null)} className="mb-4 text-indigo-400 hover:text-indigo-300">
                    &larr; Retour aux catégories
                </button>
                <h2 className="text-3xl font-bold text-white mb-2">{selectedNode.name}</h2>
                <p className="text-lg text-gray-400 mb-6">Total des dépenses: <span className="text-red-400 font-semibold">{selectedNode.total.toFixed(2)}€</span></p>

                {subCategories.length > 0 && (
                    <div className="mb-8">
                        <h3 className="text-xl font-semibold text-white mb-4">Sous-catégories</h3>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {subCategories.map(subNode => (
                                <CategoryCard key={subNode.name} node={subNode} onSelect={() => setSelectedNode(subNode)} />
                            ))}
                        </div>
                    </div>
                )}
                
                {selectedNode.transactions.length > 0 && (
                    <div>
                        <h3 className="text-xl font-semibold text-white mb-4">Transactions directes</h3>
                         <div className="bg-gray-800/50 p-4 rounded-lg">
                            {selectedNode.transactions.map(t => <TransactionRow key={t.id} transaction={t} />)}
                        </div>
                    </div>
                )}
            </div>
        )
    }

    return (
        <div>
            <h2 className="text-3xl font-bold text-white flex items-center mb-6">
                <PieChartIcon className="w-8 h-8 mr-3 text-indigo-400" />
                Gestion des Catégories
            </h2>
            
            <div className="bg-gray-800 p-6 rounded-2xl shadow-lg mb-8">
                <form onSubmit={handleAddCategory} className="flex flex-col sm:flex-row gap-3">
                    <input
                        type="text"
                        value={newCategoryName}
                        onChange={(e) => setNewCategoryName(e.target.value)}
                        placeholder="Nouvelle catégorie (ex: Loisirs > Jeux)"
                        className="flex-grow bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                    <select
                        value={newCategoryType}
                        onChange={(e) => setNewCategoryType(e.target.value as BudgetCategoryType)}
                        className="bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                        <option value="Dépense">Dépense</option>
                        <option value="Revenu">Revenu</option>
                        <option value="Épargne">Épargne</option>
                    </select>
                    <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg transition-colors flex items-center justify-center">
                        <PlusCircleIcon className="w-5 h-5 mr-2"/>
                        Ajouter
                    </button>
                </form>
            </div>

            <div className="space-y-4">
                {categoryTree.map(node => (
                    <CategoryCard key={node.name} node={node} onSelect={() => setSelectedNode(node)} />
                ))}
            </div>
            
             {categoryTree.length === 0 && (
                 <p className="text-center text-gray-400 mt-8">Aucune catégorie de dépenses trouvée. Ajoutez-en une ou catégorisez vos transactions !</p>
            )}

        </div>
    );
};

export default CategoriesView;