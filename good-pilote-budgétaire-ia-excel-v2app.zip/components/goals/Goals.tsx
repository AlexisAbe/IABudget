
import React, { useContext, useState, FormEvent, useMemo } from 'react';
import { UserContext } from '../../context/UserContext';
import { Goal, GoalSuggestion } from '../../types';
import { GoalIcon, CheckCircleIcon, TrendingUpIcon } from '../icons';
import { generateOptimizationPlan } from '../../services/geminiService';

const goalTemplates = [
    { name: "Fonds d'urgence", emoji: '🛡️' },
    { name: "Voyage", emoji: '✈️' },
    { name: "Apport Immobilier", emoji: '🏡' },
    { name: "Nouvelle voiture", emoji: '🚗' },
];

const GoalCard: React.FC<{ goal: Goal, onSelect: () => void, isSelected: boolean }> = ({ goal, onSelect, isSelected }) => {
    const progress = Math.min((goal.currentAmount / goal.targetAmount) * 100, 100);

    return (
        <div 
            onClick={onSelect}
            className={`bg-gray-800 p-5 rounded-xl shadow-lg flex flex-col justify-between cursor-pointer transition-all duration-300 ${isSelected ? 'ring-2 ring-indigo-500' : 'hover:scale-105'}`}
        >
            <div>
                <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-3">
                        <span className="text-4xl">{goal.emoji}</span>
                        <div>
                            <p className="font-bold text-white text-lg">{goal.name}</p>
                            <p className="text-sm text-gray-400">Objectif: {goal.targetAmount.toLocaleString()}€</p>
                        </div>
                    </div>
                </div>
                <div className="mt-4">
                    <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-300">{goal.currentAmount.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}€</span>
                        <span className="text-indigo-400 font-semibold">{progress.toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2.5">
                        <div className="bg-indigo-500 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                </div>
                 {goal.deadline && <p className="text-xs text-gray-500 mt-3 text-right">Avant le {new Date(goal.deadline).toLocaleDateString('fr-FR')}</p>}
            </div>
        </div>
    );
};

const GoalFeasibilityAnalysis: React.FC<{ goal: Goal, onGeneratePlan: (shortfall: number) => void, isOptimizing: boolean }> = ({ goal, onGeneratePlan, isOptimizing }) => {
    const context = useContext(UserContext);

    const analysis = useMemo(() => {
        if (!context || !goal.deadline || context.transactions.length === 0) return null;

        const now = new Date();
        const deadlineDate = new Date(goal.deadline);
        if (deadlineDate <= now) return { status: 'Échéance dépassée', statusColor: 'text-red-400', monthlyShortfall: 0, requiredMonthlySavings: 0, averageMonthlySavings: 0 };
        
        const monthsRemaining = Math.max(1, (deadlineDate.getFullYear() - now.getFullYear()) * 12 + (deadlineDate.getMonth() - now.getMonth()));
        
        const amountToSave = Math.max(0, goal.targetAmount - goal.currentAmount);
        const requiredMonthlySavings = amountToSave / monthsRemaining;

        const { transactions } = context;
        const totalNet = transactions.reduce((acc, t) => acc + (t.type === 'credit' ? t.amount : -t.amount), 0);
        const dates = transactions.map(t => new Date(t.date).getTime());
        const minDateMs = Math.min(...dates);
        const maxDateMs = Math.max(...dates);
        const monthSpan = (new Date(maxDateMs).getFullYear() - new Date(minDateMs).getFullYear()) * 12 + (new Date(maxDateMs).getMonth() - new Date(minDateMs).getMonth()) + 1;
        const averageMonthlySavings = monthSpan > 0 ? totalNet / monthSpan : 0;
        
        const monthlyShortfall = requiredMonthlySavings - averageMonthlySavings;
        
        let status = 'En bonne voie';
        let statusColor = 'text-green-400';
        if (monthlyShortfall > 0) {
            status = 'À risque';
            statusColor = 'text-yellow-400';
        }
        if (monthlyShortfall > averageMonthlySavings * 0.5 && averageMonthlySavings > 0) {
            status = 'Difficile à atteindre';
            statusColor = 'text-orange-400';
        }
        if (averageMonthlySavings <= 0 && requiredMonthlySavings > 0) {
            status = 'Plan d\'action requis';
            statusColor = 'text-red-500';
        }

        return { status, statusColor, monthlyShortfall, requiredMonthlySavings, averageMonthlySavings };
    }, [goal, context]);

    if (!analysis) return null;
    const { status, statusColor, monthlyShortfall, requiredMonthlySavings, averageMonthlySavings } = analysis;

    return (
        <div className="mb-6 p-4 border border-gray-700 rounded-lg bg-gray-800/30">
             <h4 className="text-md font-bold text-white mb-3 flex items-center">
                <TrendingUpIcon className="w-5 h-5 mr-2 text-indigo-400" />
                Analyse de Faisabilité
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                    <p className="text-sm text-gray-400">Statut</p>
                    <p className={`font-bold text-lg ${statusColor}`}>{status}</p>
                </div>
                 <div>
                    <p className="text-sm text-gray-400">Épargne Requise / mois</p>
                    <p className="font-bold text-lg text-white">{requiredMonthlySavings.toFixed(2)}€</p>
                </div>
                <div>
                    <p className="text-sm text-gray-400">Votre Moyenne / mois</p>
                    <p className="font-bold text-lg text-white">{averageMonthlySavings.toFixed(2)}€</p>
                </div>
                <div>
                    <p className="text-sm text-gray-400">Écart</p>
                    <p className={`font-bold text-lg ${monthlyShortfall > 0 ? 'text-red-400' : 'text-green-400'}`}>
                        {monthlyShortfall.toFixed(2)}€
                    </p>
                </div>
            </div>
            {monthlyShortfall > 0 && (
                <div className="text-center mt-4">
                     <button 
                        onClick={() => onGeneratePlan(monthlyShortfall)}
                        disabled={isOptimizing}
                        className="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300 disabled:opacity-50 disabled:cursor-wait">
                        {isOptimizing ? 'Analyse IA en cours...' : 'Créer un plan d\'optimisation'}
                    </button>
                </div>
            )}
        </div>
    );
};


const GoalActionPlan: React.FC<{ goal: Goal }> = ({ goal }) => {
    const context = useContext(UserContext);
    if (!context || !goal.suggestions || goal.suggestions.length === 0) return null;

    return (
        <div>
            <h3 className="text-lg font-bold text-white mb-4">Plan d'action pour : <span className="text-indigo-400">{goal.name}</span></h3>
            <ul className="space-y-3">
                {goal.suggestions.map(suggestion => (
                    <li key={suggestion.id} className="flex items-center bg-gray-700 p-3 rounded-lg">
                        <button onClick={() => context.toggleSuggestionCompleted(goal.id, suggestion.id)} className="mr-4 flex-shrink-0">
                            {suggestion.completed ? (
                                <CheckCircleIcon className="w-6 h-6 text-green-400" />
                            ) : (
                                <div className="w-6 h-6 rounded-full border-2 border-gray-500 hover:border-indigo-400"></div>
                            )}
                        </button>
                        <span className={`flex-grow ${suggestion.completed ? 'text-gray-500 line-through' : 'text-gray-300'}`}>
                            {suggestion.description}
                        </span>
                        <span className={`font-semibold ml-4 ${suggestion.completed ? 'text-green-500/70' : 'text-green-400'}`}>
                            +{suggestion.potentialSaving}€
                        </span>
                    </li>
                ))}
            </ul>
        </div>
    );
};

const Goals: React.FC = () => {
    const context = useContext(UserContext);
    const [name, setName] = useState('');
    const [targetAmount, setTargetAmount] = useState('');
    const [deadline, setDeadline] = useState('');
    const [emoji, setEmoji] = useState('🎯');
    const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);
    const [isOptimizing, setIsOptimizing] = useState(false);

    if (!context) return null;

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (name && targetAmount) {
            context.addGoal({
                name,
                targetAmount: parseFloat(targetAmount),
                emoji,
                deadline: deadline || undefined,
            });
            setName('');
            setTargetAmount('');
            setEmoji('🎯');
            setDeadline('');
        }
    };
    
    const handleGenerateOptimizationPlan = async (monthlyShortfall: number) => {
        if (!selectedGoalId) return;
        const goal = context.goals.find(g => g.id === selectedGoalId);
        if (!goal) return;

        setIsOptimizing(true);
        try {
            const suggestions = await generateOptimizationPlan(goal, context.transactions, monthlyShortfall, context.investments);
            context.addSuggestionsToGoal(selectedGoalId, suggestions as GoalSuggestion[]);
        } catch (error) {
            console.error("Failed to generate optimization plan", error);
        } finally {
            setIsOptimizing(false);
        }
    };

    const selectedGoal = context.goals.find(g => g.id === selectedGoalId);

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-white flex items-center">
                    <GoalIcon className="w-8 h-8 mr-3 text-indigo-400" />
                    Vos Objectifs de Vie
                </h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {context.goals.map(goal => (
                    <GoalCard 
                        key={goal.id} 
                        goal={goal}
                        onSelect={() => setSelectedGoalId(goal.id === selectedGoalId ? null : goal.id)}
                        isSelected={goal.id === selectedGoalId}
                    />
                ))}
            </div>
            
            {selectedGoal && (
                 <div className="mt-8 p-6 bg-gray-800/50 rounded-2xl">
                    {selectedGoal.deadline && <GoalFeasibilityAnalysis goal={selectedGoal} onGeneratePlan={handleGenerateOptimizationPlan} isOptimizing={isOptimizing} />}
                    
                    {(!selectedGoal.suggestions || selectedGoal.suggestions.length === 0) && !selectedGoal.deadline && (
                        <div className="text-center py-4">
                            <p className="text-gray-400 mb-4">Ajoutez une date limite pour obtenir une analyse de faisabilité et un plan d'action.</p>
                        </div>
                    )}
                    
                    <GoalActionPlan goal={selectedGoal} />
                </div>
            )}

            <div className="bg-gray-800 p-6 rounded-2xl shadow-lg mt-10">
                <h3 className="text-xl font-bold text-white mb-4">Ajouter un nouvel objectif</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="text-sm font-medium text-gray-400 mb-2 block">Suggestions</label>
                        <div className="flex flex-wrap gap-2">
                           {goalTemplates.map(t => (
                               <button key={t.name} type="button" onClick={() => {setName(t.name); setEmoji(t.emoji)}} className="bg-gray-700 hover:bg-indigo-600 text-gray-200 px-3 py-1 rounded-full text-sm transition-colors">
                                   {t.emoji} {t.name}
                               </button>
                           ))}
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                        <div className="md:col-span-2">
                            <label htmlFor="goal-name" className="block text-sm font-medium text-gray-300">Nom de l'objectif</label>
                            <div className="mt-1 flex rounded-md shadow-sm">
                                <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-600 bg-gray-700 text-2xl">{emoji}</span>
                                <input type="text" id="goal-name" value={name} onChange={e => setName(e.target.value)} required placeholder="Ex: Voyage au Japon" className="flex-1 block w-full rounded-none rounded-r-md bg-gray-900 border-gray-600 text-white focus:ring-indigo-500 focus:border-indigo-500" />
                            </div>
                        </div>
                        <div>
                           <label htmlFor="goal-amount" className="block text-sm font-medium text-gray-300">Montant Cible (€)</label>
                           <input type="number" id="goal-amount" value={targetAmount} onChange={e => setTargetAmount(e.target.value)} required placeholder="5000" className="mt-1 block w-full bg-gray-900 border-gray-600 text-white focus:ring-indigo-500 focus:border-indigo-500 rounded-md" />
                        </div>
                        <div>
                            <label htmlFor="goal-deadline" className="block text-sm font-medium text-gray-300">Date limite (Optionnel)</label>
                            <input type="date" id="goal-deadline" value={deadline} onChange={e => setDeadline(e.target.value)} className="mt-1 block w-full bg-gray-900 border-gray-600 text-white focus:ring-indigo-500 focus:border-indigo-500 rounded-md" />
                        </div>
                        <div className="md:col-span-2 flex items-end">
                            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 px-4 rounded-md transition duration-300">
                                Ajouter l'objectif
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Goals;
