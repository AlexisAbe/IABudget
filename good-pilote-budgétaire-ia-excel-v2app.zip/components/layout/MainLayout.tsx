import React, { useState, useContext } from 'react';
import { UserContext } from '../../context/UserContext';
import { AppView } from '../../types';
import Cockpit from '../cockpit/Cockpit';
import Goals from '../goals/Goals';
import Transactions from '../transactions/Transactions';
import CategoriesView from '../categories/CategoriesView';
import BudgetView from '../budget/BudgetView';
import ActionPlanView from '../actionplan/ActionPlanView';
import { WalletIcon, GoalIcon, ReceiptPercentIcon, PieChartIcon, LayoutGridIcon, ClipboardCheckIcon } from '../icons';

const MainLayout: React.FC = () => {
    const [currentView, setCurrentView] = useState<AppView>(AppView.Cockpit);
    const context = useContext(UserContext);

    const renderView = () => {
        switch (currentView) {
            case AppView.Cockpit:
                return <Cockpit />;
            case AppView.Transactions:
                return <Transactions />;
            case AppView.Goals:
                return <Goals />;
            case AppView.Categories:
                return <CategoriesView />;
            case AppView.Budget:
                return <BudgetView />;
            case AppView.ActionPlan:
                return <ActionPlanView />;
            default:
                return <Cockpit />;
        }
    };

    const NavItemSidebar: React.FC<{ view: AppView; label: string; icon: React.ReactNode }> = ({ view, label, icon }) => {
        const isActive = currentView === view;
        return (
            <button
                onClick={() => setCurrentView(view)}
                className={`flex items-center w-full p-3 rounded-lg transition-colors duration-200 ${
                    isActive ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'
                }`}
            >
                {icon}
                <span className="font-semibold">{label}</span>
            </button>
        );
    };

    const NavItemBottom: React.FC<{ view: AppView; label: string; icon: React.ReactNode }> = ({ view, label, icon }) => {
        const isActive = currentView === view;
        return (
            <button
                onClick={() => setCurrentView(view)}
                className={`flex flex-col items-center justify-center w-full py-2 px-1 transition-colors duration-200 ${
                    isActive ? 'text-indigo-400' : 'text-gray-500 hover:text-indigo-400'
                }`}
            >
                {icon}
                <span className={`mt-1 text-xs font-medium ${isActive ? 'text-white' : 'text-gray-400'}`}>{label}</span>
            </button>
        );
    };

    return (
        <div className="flex h-screen bg-gray-900 text-gray-100">
            {/* Sidebar (visible on md screens and up) */}
            <nav className="hidden md:flex flex-col bg-gray-800 w-64 p-4 border-r border-gray-700/50">
                <div className="mb-10 px-2">
                    <h1 className="text-xl font-bold text-white">
                        Pilote <span className="text-indigo-400">Budgétaire</span>
                    </h1>
                </div>

                <div className="flex flex-col space-y-2">
                    <NavItemSidebar view={AppView.Cockpit} label="Cockpit" icon={<WalletIcon className="w-6 h-6 mr-4" />} />
                    <NavItemSidebar view={AppView.Transactions} label="Transactions" icon={<ReceiptPercentIcon className="w-6 h-6 mr-4" />} />
                    <NavItemSidebar view={AppView.Goals} label="Objectifs" icon={<GoalIcon className="w-6 h-6 mr-4" />} />
                    <NavItemSidebar view={AppView.Categories} label="Catégories" icon={<PieChartIcon className="w-6 h-6 mr-4" />} />
                    <NavItemSidebar view={AppView.Budget} label="Budget" icon={<LayoutGridIcon className="w-6 h-6 mr-4" />} />
                    <NavItemSidebar view={AppView.ActionPlan} label="Plan d'Action" icon={<ClipboardCheckIcon className="w-6 h-6 mr-4" />} />
                </div>

                <div className="mt-auto px-2">
                    <div className="text-sm text-gray-300 mb-2">Bonjour, {context?.userProfile?.name}!</div>
                    <button onClick={context?.resetApp} className="text-xs text-gray-500 hover:text-red-400 w-full text-left">
                        Réinitialiser l'application
                    </button>
                </div>
            </nav>

            {/* Main Content Area */}
            <div className="flex flex-col flex-grow">
                 {/* Header for mobile (visible on screens smaller than md) */}
                 <header className="p-4 bg-gray-900/80 backdrop-blur-sm border-b border-gray-700/50 sticky top-0 z-10 md:hidden">
                    <div className="flex justify-between items-center">
                        <h1 className="text-xl font-bold text-white">
                            Pilote <span className="text-indigo-400">Budgétaire</span>
                        </h1>
                        <button onClick={context?.resetApp} className="text-xs text-gray-500 hover:text-red-400">
                            Reset
                        </button>
                    </div>
                </header>

                <main className="flex-grow p-4 md:p-6 lg:p-8 overflow-y-auto">
                    <div className="max-w-7xl mx-auto">
                        {renderView()}
                    </div>
                </main>

                {/* Bottom Nav (visible on screens smaller than md) */}
                <nav className="sticky bottom-0 bg-gray-800 border-t border-gray-700/50 md:hidden">
                    <div className="flex justify-around max-w-7xl mx-auto">
                        <NavItemBottom view={AppView.Cockpit} label="Cockpit" icon={<WalletIcon className="w-6 h-6" />} />
                        <NavItemBottom view={AppView.Transactions} label="Transactions" icon={<ReceiptPercentIcon className="w-6 h-6" />} />
                        <NavItemBottom view={AppView.Goals} label="Objectifs" icon={<GoalIcon className="w-6 h-6" />} />
                        <NavItemBottom view={AppView.Categories} label="Catégories" icon={<PieChartIcon className="w-6 h-6" />} />
                        <NavItemBottom view={AppView.Budget} label="Budget" icon={<LayoutGridIcon className="w-6 h-6" />} />
                        <NavItemBottom view={AppView.ActionPlan} label="Plan d'Action" icon={<ClipboardCheckIcon className="w-6 h-6" />} />
                    </div>
                </nav>
            </div>
        </div>
    );
};

export default MainLayout;