import React, { useState, useContext, FormEvent } from 'react';
import { UserContext } from '../../context/UserContext';
import { BudgetCategoryType, BudgetCategory } from '../../types';

const BudgetCategories: React.FC = () => {
    const context = useContext(UserContext);
    const [newCategoryName, setNewCategoryName] = useState('');
    const [newCategoryType, setNewCategoryType] = useState<BudgetCategoryType>('Dépense');
    const [editingCategory, setEditingCategory] = useState<BudgetCategory | null>(null);

    if (!context) return null;

    const { budgetCategories, addBudgetCategory, updateBudgetCategory, deleteBudgetCategory } = context;

    const handleAddSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (newCategoryName.trim()) {
            addBudgetCategory({ name: newCategoryName.trim(), type: newCategoryType });
            setNewCategoryName('');
            setNewCategoryType('Dépense');
        }
    };

    const handleUpdateSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (editingCategory && editingCategory.name.trim()) {
            updateBudgetCategory(editingCategory);
            setEditingCategory(null);
        }
    };

    const renderCategoryList = (type: BudgetCategoryType) => {
        const categoriesOfType = budgetCategories.filter(c => c.type === type);
        return (
            <div className="mb-8">
                <h3 className="text-xl font-bold text-white mb-3">{type}</h3>
                {categoriesOfType.length > 0 ? (
                    <div className="space-y-2">
                        {categoriesOfType.map(cat => (
                            <div key={cat.id} className="bg-gray-700 p-3 rounded-lg flex items-center justify-between">
                                {editingCategory?.id === cat.id ? (
                                    <form onSubmit={handleUpdateSubmit} className="flex-grow flex items-center gap-2">
                                        <input 
                                            type="text" 
                                            value={editingCategory.name} 
                                            onChange={e => setEditingCategory({...editingCategory, name: e.target.value})}
                                            className="bg-gray-900 border-gray-600 rounded px-2 py-1 text-white w-full"
                                            autoFocus
                                        />
                                        <select 
                                            value={editingCategory.type} 
                                            onChange={e => setEditingCategory({...editingCategory, type: e.target.value as BudgetCategoryType})}
                                            className="bg-gray-900 border-gray-600 rounded px-2 py-1 text-white"
                                        >
                                            <option value="Dépense">Dépense</option>
                                            <option value="Revenu">Revenu</option>
                                            <option value="Épargne">Épargne</option>
                                        </select>
                                        <button type="submit" className="text-green-400 hover:text-green-300 px-2">Sauver</button>
                                        <button type="button" onClick={() => setEditingCategory(null)} className="text-gray-400 hover:text-gray-300 px-2">Annuler</button>
                                    </form>
                                ) : (
                                    <>
                                        <span className="font-medium text-white">{cat.name}</span>
                                        <div className="flex items-center gap-4">
                                            <button onClick={() => setEditingCategory(cat)} className="text-sm text-indigo-400 hover:text-indigo-300">Modifier</button>
                                            <button onClick={() => window.confirm(`Voulez-vous vraiment supprimer la catégorie "${cat.name}" ?`) && deleteBudgetCategory(cat.id)} className="text-sm text-red-400 hover:text-red-300">Supprimer</button>
                                        </div>
                                    </>
                                )}
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-gray-500">Aucune catégorie de ce type.</p>
                )}
            </div>
        );
    };

    return (
        <div className="bg-gray-800/50 p-6 rounded-2xl shadow-lg">
            <div className="border-b border-gray-700 pb-4 mb-4">
                <h2 className="text-2xl font-bold text-white">Gestion des Catégories Budgétaires</h2>
                <p className="text-gray-400 mt-1">Ces catégories servent à structurer votre planificateur budgétaire et à analyser vos dépenses. Vous pouvez les personnaliser à volonté.</p>
            </div>
            
            <div className="bg-gray-700/50 p-4 rounded-lg mb-8">
                 <h3 className="font-bold text-white mb-3">Ajouter une catégorie</h3>
                <form onSubmit={handleAddSubmit} className="flex flex-col sm:flex-row gap-3">
                    <input
                        type="text"
                        value={newCategoryName}
                        onChange={(e) => setNewCategoryName(e.target.value)}
                        placeholder="Nom de la catégorie"
                        className="flex-grow bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                    <select
                        value={newCategoryType}
                        onChange={(e) => setNewCategoryType(e.target.value as BudgetCategoryType)}
                        className="bg-gray-900 border border-gray-600 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-indigo-500 outline-none"
                    >
                        <option value="Dépense">Dépense</option>
                        <option value="Revenu">Revenu</option>
                        <option value="Épargne">Épargne</option>
                    </select>
                    <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg transition-colors">
                        Ajouter
                    </button>
                </form>
            </div>

            {renderCategoryList('Revenu')}
            {renderCategoryList('Dépense')}
            {renderCategoryList('Épargne')}
        </div>
    );
};

export default BudgetCategories;