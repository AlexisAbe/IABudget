import React, { useState, useEffect } from 'react';
import { PrefillAnalysisResult } from '../../services/geminiService';

interface VerificationModalProps {
    isOpen: boolean;
    initialData: PrefillAnalysisResult;
    onClose: () => void;
    onConfirm: (confirmedData: PrefillAnalysisResult) => void;
}

const VerificationModal: React.FC<VerificationModalProps> = ({ isOpen, initialData, onClose, onConfirm }) => {
    const [confirmedData, setConfirmedData] = useState<PrefillAnalysisResult>(initialData);

    useEffect(() => {
        setConfirmedData(initialData);
    }, [initialData]);

    const handleAmountChange = (field: 'salary' | 'rent', value: string) => {
        const amount = parseFloat(value) || 0;
        setConfirmedData(prev => ({
            ...prev,
            [field]: { amount }
        }));
    };
    
    const handleQuestionAmountChange = (index: number, value: string) => {
        const amount = parseFloat(value) || 0;
        const newQuestions = [...confirmedData.questions];
        newQuestions[index] = { ...newQuestions[index], suggestedAmount: amount };
        setConfirmedData(prev => ({
            ...prev,
            questions: newQuestions
        }));
    };
    
    const handleSubmit = () => {
        onConfirm(confirmedData);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
            <div className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col border border-gray-700">
                <div className="p-6 border-b border-gray-700">
                    <h2 className="text-2xl font-bold text-white">Vérification des Données Clés</h2>
                    <p className="text-sm text-gray-400">L'IA a analysé vos transactions. Veuillez vérifier ces estimations avant de remplir votre budget.</p>
                </div>

                <div className="p-6 overflow-y-auto space-y-6">
                    {/* Salaire */}
                    <div className="bg-gray-700/50 p-4 rounded-lg">
                        <label htmlFor="salary" className="block text-lg font-semibold text-white mb-2">💰 Salaire Mensuel Estimé</label>
                        <p className="text-sm text-gray-400 mb-3">Nous avons estimé votre revenu mensuel principal. Est-ce correct ?</p>
                        <div className="relative">
                            <input
                                id="salary"
                                type="number"
                                value={confirmedData.salary.amount}
                                onChange={e => handleAmountChange('salary', e.target.value)}
                                className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                            />
                            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">€</span>
                        </div>
                    </div>
                    
                     {/* Loyer / Crédit */}
                     <div className="bg-gray-700/50 p-4 rounded-lg">
                        <label htmlFor="rent" className="block text-lg font-semibold text-white mb-2">🏠 Loyer / Crédit Mensuel Estimé</label>
                        <p className="text-sm text-gray-400 mb-3">Voici notre estimation pour votre principale dépense de logement.</p>
                         <div className="relative">
                             <input
                                id="rent"
                                type="number"
                                value={confirmedData.rent.amount}
                                onChange={e => handleAmountChange('rent', e.target.value)}
                                className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                             />
                             <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">€</span>
                        </div>
                    </div>

                    {/* Questions dynamiques */}
                    {confirmedData.questions.map((q, index) => (
                        <div key={index} className="bg-gray-700/50 p-4 rounded-lg">
                            <label htmlFor={`question-${index}`} className="block text-lg font-semibold text-white mb-2">❓ {q.categoryName}</label>
                            <p className="text-sm text-gray-400 mb-3">{q.question}</p>
                            <div className="relative">
                                <input
                                    id={`question-${index}`}
                                    type="number"
                                    value={q.suggestedAmount}
                                    onChange={e => handleQuestionAmountChange(index, e.target.value)}
                                    className="w-full bg-gray-900 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                />
                                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400">€</span>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="p-6 mt-auto border-t border-gray-700 flex justify-end gap-3 bg-gray-800/50 rounded-b-2xl">
                    <button onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg transition-colors">Annuler</button>
                    <button onClick={handleSubmit} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition-colors">Confirmer & Remplir</button>
                </div>
            </div>
        </div>
    );
};

export default VerificationModal;
