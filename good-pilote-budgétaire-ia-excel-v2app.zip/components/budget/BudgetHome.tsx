import React from 'react';
import { BudgetView } from '../../types';
import { ReceiptPercentIcon, PieChartIcon, ArrowRightIcon, LayoutGridIcon } from '../icons';

interface BudgetHomeProps {
    setActiveView: (view: BudgetView) => void;
}

const BudgetHome: React.FC<BudgetHomeProps> = ({ setActiveView }) => {

    const menuItems = [
        { view: BudgetView.Monthly, title: "Tableau de bord mensuel", description: "Analysez vos revenus, dépenses et épargne pour le mois en cours.", icon: <LayoutGridIcon className="w-8 h-8 text-indigo-400" /> },
        { view: BudgetView.Annual, title: "Synthèse annuelle", description: "Visualisez votre performance financière sur toute l'année.", icon: <LayoutGridIcon className="w-8 h-8 text-green-400" /> },
        { view: BudgetView.Comparison, title: "Comparateur personnalisé", description: "Comparez les dépenses de deux mois côte à côte.", icon: <LayoutGridIcon className="w-8 h-8 text-yellow-400" /> },
        { view: BudgetView.Planner, title: "Planification annuelle", description: "Fixez vos objectifs de revenus et dépenses pour chaque mois.", icon: <LayoutGridIcon className="w-8 h-8 text-blue-400" /> },
        { view: BudgetView.Transactions, title: "Suivi des transactions", description: "Consultez et gérez l'ensemble de vos transactions.", icon: <ReceiptPercentIcon className="w-8 h-8 text-purple-400" /> },
        { view: BudgetView.BudgetCategories, title: "Catégories personnalisées", description: "Créez et gérez vos propres catégories de budget.", icon: <PieChartIcon className="w-8 h-8 text-pink-400" /> },
    ];

    return (
        <div>
            <div className="mb-8 text-center">
                <h1 className="text-4xl font-extrabold text-white">Tableau Budgétaire Structuré</h1>
                <p className="mt-2 text-lg text-gray-400">Votre centre de commande pour une analyse financière détaillée et une planification précise.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {menuItems.map(item => (
                    <div 
                        key={item.view} 
                        onClick={() => setActiveView(item.view)}
                        className="bg-gray-800 rounded-2xl p-6 flex flex-col justify-between hover:bg-gray-700/50 hover:ring-2 hover:ring-indigo-500 transition-all duration-300 cursor-pointer shadow-lg"
                    >
                        <div>
                            <div className="mb-4">{item.icon}</div>
                            <h3 className="text-xl font-bold text-white">{item.title}</h3>
                            <p className="text-gray-400 mt-2 text-sm">{item.description}</p>
                        </div>
                        <div className="mt-6 flex justify-end items-center">
                            <span className="text-indigo-400 font-semibold text-sm">Accéder</span>
                            <ArrowRightIcon className="w-4 h-4 ml-2 text-indigo-400" />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default BudgetHome;