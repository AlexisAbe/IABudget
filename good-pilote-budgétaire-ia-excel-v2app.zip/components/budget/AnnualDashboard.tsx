import React, { useState, useContext, useMemo } from 'react';
import { UserContext } from '../../context/UserContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const AnnualDashboard: React.FC = () => {
    const context = useContext(UserContext);
    const [year, setYear] = useState(new Date().getFullYear());

    const annualData = useMemo(() => {
        if (!context) return null;
        const { transactions } = context;
        
        const filteredTransactions = transactions.filter(t => new Date(t.date).getFullYear() === year);

        const totalIncome = filteredTransactions.filter(t => t.type === 'credit').reduce((sum, t) => sum + t.amount, 0);
        const totalExpenses = filteredTransactions.filter(t => t.type === 'debit').reduce((sum, t) => sum + t.amount, 0);
        const totalSavings = totalIncome - totalExpenses;

        const monthlyData = Array.from({ length: 12 }, (_, i) => {
            const month = i + 1;
            const monthTransactions = filteredTransactions.filter(t => new Date(t.date).getMonth() + 1 === month);
            const income = monthTransactions.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0);
            const expenses = monthTransactions.filter(t => t.type === 'debit').reduce((s, t) => s + t.amount, 0);
            return {
                name: new Date(year, i).toLocaleString('fr-FR', { month: 'short' }),
                revenus: income,
                depenses: expenses,
                solde: income - expenses
            };
        });

        return { totalIncome, totalExpenses, totalSavings, monthlyData };
    }, [context, year]);

    if (!context) return <div className="text-white">Chargement...</div>;
    const { currency } = context;

    const availableYears = Array.from(new Set(context.transactions.map(t => new Date(t.date).getFullYear()))).sort((a, b) => b - a);

    return (
        <div className="bg-gray-800/50 p-6 rounded-2xl shadow-lg">
            <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <h2 className="text-2xl font-bold text-white">Synthèse Annuelle</h2>
                <select 
                    value={year} 
                    onChange={e => setYear(parseInt(e.target.value))} 
                    className="bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500"
                >
                    {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
            </div>

            {annualData ? (
                 <>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div className="bg-gray-700 p-4 rounded-lg text-center"><p className="text-sm text-gray-400">Revenus Annuels</p><p className="text-2xl font-bold text-green-400">{annualData.totalIncome.toFixed(2)}{currency}</p></div>
                        <div className="bg-gray-700 p-4 rounded-lg text-center"><p className="text-sm text-gray-400">Dépenses Annuelles</p><p className="text-2xl font-bold text-red-400">{annualData.totalExpenses.toFixed(2)}{currency}</p></div>
                        <div className="bg-gray-700 p-4 rounded-lg text-center"><p className="text-sm text-gray-400">Épargne Annuelle</p><p className={`text-2xl font-bold ${annualData.totalSavings >= 0 ? 'text-blue-400' : 'text-orange-400'}`}>{annualData.totalSavings.toFixed(2)}{currency}</p></div>
                    </div>

                    <div className="bg-gray-700/50 p-4 rounded-lg">
                         <h3 className="font-bold text-white mb-4">Évolution Mensuelle du Solde Net</h3>
                        <div style={{ width: '100%', height: 400 }}>
                            <ResponsiveContainer>
                                <BarChart data={annualData.monthlyData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#4a5568" />
                                    <XAxis dataKey="name" stroke="#a0aec0" />
                                    <YAxis stroke="#a0aec0" tickFormatter={(value) => `${value}${currency}`} />
                                    <Tooltip 
                                        cursor={{ fill: 'rgba(129, 140, 248, 0.1)' }}
                                        contentStyle={{ backgroundColor: '#2d3748', border: '1px solid #4a5568' }} 
                                        labelStyle={{ color: '#e2e8f0' }}
                                        formatter={(value: number) => `${value.toFixed(2)}${currency}`}
                                    />
                                    <Legend />
                                    <Bar dataKey="solde" name="Solde Net" fill="#8884d8" />
                                    <Bar dataKey="revenus" name="Revenus" fill="#82ca9d" />
                                    <Bar dataKey="depenses" name="Dépenses" fill="#ff8042" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                 </>
            ) : (
                <div className="h-64 flex items-center justify-center bg-gray-700/50 rounded-lg">
                    <p className="text-gray-500">Aucune donnée pour cette année.</p>
                </div>
            )}
        </div>
    );
};

export default AnnualDashboard;