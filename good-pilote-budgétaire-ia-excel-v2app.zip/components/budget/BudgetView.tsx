import React, { useState } from 'react';
import { BudgetView as BudgetViewEnum } from '../../types';
import BudgetHome from './BudgetHome';
import MonthlyDashboard from './MonthlyDashboard';
import AnnualDashboard from './AnnualDashboard';
import ComparisonDashboard from './ComparisonDashboard';
import BudgetPlanner from './BudgetPlanner';
import TransactionsTable from './TransactionsTable';
import BudgetCategories from './BudgetCategories';

const BudgetView: React.FC = () => {
    const [activeView, setActiveView] = useState<BudgetViewEnum>(BudgetViewEnum.Home);

    const renderActiveView = () => {
        switch(activeView) {
            case BudgetViewEnum.Home:
                return <BudgetHome setActiveView={setActiveView} />;
            case BudgetViewEnum.Monthly:
                return <MonthlyDashboard />;
            case BudgetViewEnum.Annual:
                return <AnnualDashboard />;
            case BudgetViewEnum.Comparison:
                return <ComparisonDashboard />;
            case BudgetViewEnum.Planner:
                return <BudgetPlanner />;
            case BudgetViewEnum.Transactions:
                return <TransactionsTable />;
            case BudgetViewEnum.BudgetCategories:
                return <BudgetCategories />;
            default:
                return <BudgetHome setActiveView={setActiveView} />;
        }
    }
    
    return (
        <div>
            {activeView !== BudgetViewEnum.Home && (
                 <button 
                    onClick={() => setActiveView(BudgetViewEnum.Home)} 
                    className="mb-6 text-sm text-indigo-400 hover:text-indigo-300 transition-colors"
                >
                    &larr; Retour au hub budgétaire
                </button>
            )}
            {renderActiveView()}
        </div>
    );
};

export default BudgetView;
