import React, { useState, useContext, useMemo } from 'react';
import { UserContext } from '../../context/UserContext';

const ComparisonDashboard: React.FC = () => {
    const context = useContext(UserContext);
    const now = new Date();
    const [periodA, setPeriodA] = useState({ month: now.getMonth(), year: now.getFullYear() }); // Previous month
    const [periodB, setPeriodB] = useState({ month: now.getMonth() + 1, year: now.getFullYear() }); // Current month

    const getPeriodData = (month: number, year: number) => {
        if (!context) return { totalIncome: 0, totalExpenses: 0, expensesByCategory: {} };
        const { transactions } = context;
        
        const filtered = transactions.filter(t => {
            const d = new Date(t.date);
            return d.getMonth() + 1 === month && d.getFullYear() === year;
        });
        
        const totalIncome = filtered.filter(t => t.type === 'credit').reduce((s, t) => s + t.amount, 0);
        const totalExpenses = filtered.filter(t => t.type === 'debit').reduce((s, t) => s + t.amount, 0);
        const expensesByCategory = filtered
            .filter(t => t.type === 'debit' && t.category)
            .reduce((acc, t) => {
                const cat = t.category || 'Non classé';
                acc[cat] = (acc[cat] || 0) + t.amount;
                return acc;
            }, {} as Record<string, number>);

        return { totalIncome, totalExpenses, expensesByCategory };
    };

    const dataA = useMemo(() => getPeriodData(periodA.month, periodA.year), [context, periodA]);
    const dataB = useMemo(() => getPeriodData(periodB.month, periodB.year), [context, periodB]);

    const allCategories = useMemo(() => {
        return [...new Set([...Object.keys(dataA.expensesByCategory), ...Object.keys(dataB.expensesByCategory)])].sort();
    }, [dataA, dataB]);

    if (!context) return <div className="text-white">Chargement...</div>;
    const { currency } = context;

    const availableYears = Array.from(new Set(context.transactions.map(t => new Date(t.date).getFullYear()))).sort((a,b) => b-a);
    const months = Array.from({length: 12}, (_, i) => ({ value: i+1, name: new Date(0, i).toLocaleString('fr-FR', { month: 'long' })}));

    const PeriodSelector: React.FC<{period: {month: number, year: number}, setPeriod: (p: {month: number, year: number}) => void}> = ({period, setPeriod}) => (
        <div className="flex gap-2">
            <select value={period.month} onChange={e => setPeriod({...period, month: parseInt(e.target.value)})} className="bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500">
                {months.map(m => <option key={m.value} value={m.value}>{m.name}</option>)}
            </select>
            <select value={period.year} onChange={e => setPeriod({...period, year: parseInt(e.target.value)})} className="bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500">
                {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
        </div>
    );

    const formatDiff = (diff: number) => {
        if (diff > 0) return <span className="text-red-400">(+{diff.toFixed(2)}{currency})</span>;
        if (diff < 0) return <span className="text-green-400">({diff.toFixed(2)}{currency})</span>;
        return <span className="text-gray-500">({diff.toFixed(2)}{currency})</span>;
    }

    return (
        <div className="bg-gray-800/50 p-6 rounded-2xl shadow-lg">
            <h2 className="text-2xl font-bold text-white mb-6">Comparateur de Mois</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <h3 className="text-lg font-bold text-indigo-400 mb-2">Période A</h3>
                    <PeriodSelector period={periodA} setPeriod={setPeriodA} />
                    <div className="mt-4 space-y-2">
                        <p>Revenus: <span className="font-semibold text-green-400">{dataA.totalIncome.toFixed(2)}{currency}</span></p>
                        <p>Dépenses: <span className="font-semibold text-red-400">{dataA.totalExpenses.toFixed(2)}{currency}</span></p>
                    </div>
                </div>
                 <div>
                    <h3 className="text-lg font-bold text-indigo-400 mb-2">Période B</h3>
                    <PeriodSelector period={periodB} setPeriod={setPeriodB} />
                     <div className="mt-4 space-y-2">
                        <p>Revenus: <span className="font-semibold text-green-400">{dataB.totalIncome.toFixed(2)}{currency}</span></p>
                        <p>Dépenses: <span className="font-semibold text-red-400">{dataB.totalExpenses.toFixed(2)}{currency}</span></p>
                    </div>
                </div>
            </div>

            <div className="mt-8">
                <h3 className="text-xl font-bold text-white mb-4">Analyse par Catégorie</h3>
                <div className="overflow-x-auto bg-gray-700/50 p-4 rounded-lg">
                    <table className="w-full text-sm text-left text-gray-300">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-800">
                            <tr>
                                <th className="px-4 py-3">Catégorie</th>
                                <th className="px-4 py-3 text-right">Période A</th>
                                <th className="px-4 py-3 text-right">Période B</th>
                                <th className="px-4 py-3 text-right">Variation</th>
                            </tr>
                        </thead>
                        <tbody>
                            {allCategories.map(cat => {
                                const valA = dataA.expensesByCategory[cat] || 0;
                                const valB = dataB.expensesByCategory[cat] || 0;
                                const diff = valB - valA;
                                return (
                                    <tr key={cat} className="border-b border-gray-600">
                                        <td className="px-4 py-3 font-medium text-white">{cat}</td>
                                        <td className="px-4 py-3 text-right font-mono">{valA.toFixed(2)}{currency}</td>
                                        <td className="px-4 py-3 text-right font-mono">{valB.toFixed(2)}{currency}</td>
                                        <td className="px-4 py-3 text-right font-mono">{formatDiff(diff)}</td>
                                    </tr>
                                )
                            })}
                            <tr className="bg-gray-800 font-bold">
                                <td className="px-4 py-3">Total Dépenses</td>
                                <td className="px-4 py-3 text-right font-mono">{dataA.totalExpenses.toFixed(2)}{currency}</td>
                                <td className="px-4 py-3 text-right font-mono">{dataB.totalExpenses.toFixed(2)}{currency}</td>
                                <td className="px-4 py-3 text-right font-mono">{formatDiff(dataB.totalExpenses - dataA.totalExpenses)}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    );
};

export default ComparisonDashboard;