
import React, { useState, useContext, useMemo, useEffect } from 'react';
import { UserContext } from '../../context/UserContext';
import { BudgetCategory, BudgetCategoryType, BudgetPlanItem, Transaction } from '../../types';
import { SparklesIcon } from '../icons';
import { mapTransactionCategoriesToBudget, analyzeForBudgetPreFill, PrefillAnalysisResult } from '../../services/geminiService';
import VerificationModal from './VerificationModal';

const BudgetPlanner: React.FC = () => {
    const context = useContext(UserContext);
    const [year, setYear] = useState(new Date().getFullYear());
    
    const [isLoading, setIsLoading] = useState(false);
    const [progress, setProgress] = useState(0);
    const [progressMessage, setProgressMessage] = useState('');
    
    const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
    const [verificationData, setVerificationData] = useState<PrefillAnalysisResult | null>(null);

    const [projectionInfo, setProjectionInfo] = useState<{ basis: string; reliability: string; color: string; } | null>(null);
    
    useEffect(() => {
        setProjectionInfo(null);
    }, [year]);

    if (!context) return null;
    
    const { budgetCategories, budgetPlan, updateBudgetPlanItem, currency, transactions, setBudgetPlan } = context;

    const handleAutoFill = async () => {
        if (isLoading) return;
        
        setIsLoading(true);
        setProgress(0);
        setProgressMessage("Analyse initiale de l'IA...");
        setVerificationData(null);
        setProjectionInfo(null);
        
        try {
            if (transactions.length === 0) {
                throw new Error("Aucune donnée transactionnelle n'est disponible.");
            }
            
            setProgress(50);
            const analysisResult = await analyzeForBudgetPreFill(transactions, budgetCategories);
            setProgress(100);
            
            setVerificationData(analysisResult);
            setIsVerificationModalOpen(true);

        } catch (e: any) {
             alert(e.message || "Une erreur est survenue durant l'analyse IA.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleConfirmVerification = async (confirmedData: PrefillAnalysisResult) => {
        setIsVerificationModalOpen(false);
        setIsLoading(true);
        setProgress(0);
        setProgressMessage('Application des prévisions...');
        await new Promise(res => setTimeout(res, 50)); // Allow UI to update
        
        try {
            // 1. Map all transaction categories to budget categories
            const transactionCategories = [...new Set(transactions.filter(t => t.category).map(t => t.category!))];
            const categoryMap = await mapTransactionCategoriesToBudget(transactionCategories, budgetCategories);
            setProgress(25);
            
            // 2. Aggregate all transactions based on the mapping
            const transactionsByBudgetCategory: Record<string, Transaction[]> = {};
            transactions.forEach(t => {
                const mappedCategoryName = t.category ? categoryMap[t.category] : null;
                if (mappedCategoryName) {
                    const budgetCategory = budgetCategories.find(bc => bc.name === mappedCategoryName);
                    if (budgetCategory) {
                        if (!transactionsByBudgetCategory[budgetCategory.id]) {
                            transactionsByBudgetCategory[budgetCategory.id] = [];
                        }
                        transactionsByBudgetCategory[budgetCategory.id].push(t);
                    }
                }
            });
            setProgress(50);

            // 3. Calculate general monthly averages
            const validDates = transactions.map(t => new Date(t.date).getTime()).filter(t => !isNaN(t));
            const minDate = new Date(Math.min(...validDates));
            const maxDate = new Date(Math.max(...validDates));
            const monthSpan = Math.max(1, (maxDate.getFullYear() - minDate.getFullYear()) * 12 + (maxDate.getMonth() - minDate.getMonth()) + 1);

            const newPlanItems: BudgetPlanItem[] = [];
            const processedCategories = new Set<string>();

            // 4. Add user-confirmed data
            const { salary, rent, questions } = confirmedData;

            const salaryCat = budgetCategories.find(c => c.type === 'Revenu'); // Simplified: gets first income category
            if (salaryCat) {
                for (let i = 1; i <= 12; i++) newPlanItems.push({ categoryId: salaryCat.id, month: i, year, plannedAmount: salary.amount, isProjected: false });
                processedCategories.add(salaryCat.id);
            }
            
            const rentCat = budgetCategories.find(c => c.name.toLowerCase().includes('loyer') || c.name.toLowerCase().includes('crédit'));
            if (rentCat) {
                for (let i = 1; i <= 12; i++) newPlanItems.push({ categoryId: rentCat.id, month: i, year, plannedAmount: rent.amount, isProjected: false });
                 processedCategories.add(rentCat.id);
            }

            questions.forEach(q => {
                const questionCat = budgetCategories.find(c => c.name === q.categoryName);
                if (questionCat) {
                     for (let i = 1; i <= 12; i++) newPlanItems.push({ categoryId: questionCat.id, month: i, year, plannedAmount: q.suggestedAmount, isProjected: false });
                    processedCategories.add(questionCat.id);
                }
            });
            setProgress(75);

            // 5. Fill remaining categories with AI averages
            for (const categoryId in transactionsByBudgetCategory) {
                if (processedCategories.has(categoryId)) continue;

                const categoryTransactions = transactionsByBudgetCategory[categoryId];
                const total = categoryTransactions.reduce((sum, t) => sum + t.amount, 0);
                const average = total / monthSpan;

                if (average > 0) {
                    for (let month = 1; month <= 12; month++) {
                        newPlanItems.push({ categoryId, month, year, plannedAmount: Math.round(average), isProjected: true });
                    }
                }
            }
            
            const planForOtherYears = budgetPlan.filter(p => p.year !== year);
            setBudgetPlan([...planForOtherYears, ...newPlanItems]);

            // Set projection info
            const basisText = `Projection basée sur ${monthSpan} mois de données.`;
            let reliabilityText = 'Fiabilité élevée';
            let reliabilityColor = 'text-green-400';
            if (monthSpan < 3) { reliabilityText = 'Fiabilité faible'; reliabilityColor = 'text-orange-400'; }
            else if (monthSpan < 12) { reliabilityText = 'Fiabilité moyenne'; reliabilityColor = 'text-yellow-400'; }
            setProjectionInfo({ basis: basisText, reliability: reliabilityText, color: reliabilityColor });

            setProgress(100);
            setProgressMessage("Terminé !");

        } catch (e: any) {
            alert("Erreur lors de la finalisation du budget.");
        } finally {
            setTimeout(() => setIsLoading(false), 1000);
        }
    };


    const handlePlanChange = (categoryId: string, month: number, value: string) => {
        const amount = parseFloat(value) || 0;
        updateBudgetPlanItem({ categoryId, month, year, plannedAmount: amount });
    };

    const availableYears = useMemo(() => {
      const transactionYears = context.transactions.map(t => new Date(t.date).getFullYear());
      const planYears = context.budgetPlan.map(p => p.year);
      const currentYear = new Date().getFullYear();
      return Array.from(new Set([currentYear, currentYear + 1, ...transactionYears, ...planYears])).sort((a,b) => b-a);
    }, [context.transactions, context.budgetPlan]);

    const summaryData = useMemo(() => {
        const planForYear = budgetPlan.filter(p => p.year === year);
        let totalIncome = 0;
        let totalExpenses = 0;
        let totalSavings = 0;

        planForYear.forEach(item => {
            const category = budgetCategories.find(c => c.id === item.categoryId);
            if(category) {
                switch(category.type) {
                    case 'Revenu': totalIncome += item.plannedAmount; break;
                    case 'Dépense': totalExpenses += item.plannedAmount; break;
                    case 'Épargne': totalSavings += item.plannedAmount; break;
                }
            }
        });
        
        const netBalance = totalIncome - totalExpenses - totalSavings;

        return { totalIncome, totalExpenses, totalSavings, netBalance };
    }, [year, budgetPlan, budgetCategories]);


    const renderCategorySection = (type: BudgetCategoryType) => {
        const categoriesOfType = budgetCategories.filter(c => c.type === type);
        if (categoriesOfType.length === 0) return null;

        const monthlyTotals = Array.from({ length: 12 }, () => 0);
        categoriesOfType.forEach(cat => {
            for (let i = 0; i < 12; i++) {
                const month = i + 1;
                const planItem = budgetPlan.find(p => p.categoryId === cat.id && p.month === month && p.year === year);
                if (planItem) {
                    monthlyTotals[i] += planItem.plannedAmount;
                }
            }
        });
        const sectionGrandTotal = monthlyTotals.reduce((sum, current) => sum + current, 0);

        return (
            <div className="mb-8">
                <h3 className="text-xl font-bold text-white mb-3">{type}</h3>
                <div className="overflow-x-auto bg-gray-700/50 rounded-lg">
                    <table className="w-full text-sm text-left text-gray-300">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-800">
                            <tr>
                                <th className="px-4 py-3 sticky left-0 bg-gray-800 z-10 min-w-[200px] lg:min-w-[250px]">Catégorie</th>
                                {Array.from({ length: 12 }, (_, i) => (
                                    <th key={i} className="px-4 py-3 text-center">{new Date(year, i).toLocaleString('fr-FR', { month: 'short' }).replace('.', '')}</th>
                                ))}
                                <th className="px-4 py-3 text-right min-w-[120px]">Total Annuel</th>
                            </tr>
                        </thead>
                        <tbody>
                            {categoriesOfType.map(cat => {
                                const yearTotal = budgetPlan
                                    .filter(p => p.categoryId === cat.id && p.year === year)
                                    .reduce((sum, p) => sum + p.plannedAmount, 0);

                                return (
                                <tr key={cat.id} className="border-b border-gray-600">
                                    <td className="px-4 py-2 font-medium text-white sticky left-0 bg-gray-700/80 z-10">{cat.name}</td>
                                    {Array.from({ length: 12 }, (_, i) => {
                                        const month = i + 1;
                                        const planItem = budgetPlan.find(p => p.categoryId === cat.id && p.month === month && p.year === year);
                                        const isProjected = planItem?.isProjected;
                                        return (
                                            <td key={month} className="px-2 py-1">
                                                <input
                                                    type="number"
                                                    value={planItem?.plannedAmount !== 0 ? planItem?.plannedAmount || '' : '0'}
                                                    onChange={e => handlePlanChange(cat.id, month, e.target.value)}
                                                    onFocus={e => e.target.select()}
                                                    placeholder="0"
                                                    className={`w-24 bg-transparent border-none text-right px-2 py-1 focus:ring-1 focus:ring-indigo-500 focus:bg-gray-900 rounded-md ${isProjected ? 'italic text-indigo-300/80' : 'text-white'}`}
                                                />
                                            </td>
                                        )
                                    })}
                                    <td className="px-4 py-2 text-right font-bold text-indigo-300">{yearTotal.toFixed(2)}{currency}</td>
                                </tr>
                            )})}
                            <tr className="bg-gray-800 font-bold text-white border-t-2 border-indigo-500">
                                <td className="px-4 py-3 sticky left-0 bg-gray-800 z-10">Total {type}</td>
                                {monthlyTotals.map((total, i) => (
                                    <td key={`total-${type}-${i}`} className="px-4 py-3 text-center">
                                        {total.toFixed(2)}{currency}
                                    </td>
                                ))}
                                <td className="px-4 py-3 text-right text-indigo-300">
                                    {sectionGrandTotal.toFixed(2)}{currency}
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        );
    };

    return (
        <div className="bg-gray-800/50 p-6 rounded-2xl shadow-lg">
            {isVerificationModalOpen && verificationData && (
                <VerificationModal 
                    isOpen={isVerificationModalOpen}
                    initialData={verificationData}
                    onClose={() => setIsVerificationModalOpen(false)}
                    onConfirm={handleConfirmVerification}
                />
            )}
            <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <h2 className="text-2xl font-bold text-white">Planification Annuelle</h2>
                <div className="flex items-center gap-4">
                    <button
                        onClick={handleAutoFill}
                        disabled={isLoading}
                        className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-wait"
                    >
                        <SparklesIcon className="w-5 h-5"/>
                        {isLoading ? 'Analyse...' : "Pré-remplir avec IA"}
                    </button>
                    <select 
                        value={year} 
                        onChange={e => setYear(parseInt(e.target.value))} 
                        className="bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500"
                    >
                        {availableYears.map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                </div>
            </div>

            {isLoading && (
                <div className="mb-6">
                    <div className="flex justify-between mb-1">
                        <span className="text-base font-medium text-gray-300">{progressMessage}</span>
                        <span className="text-sm font-medium text-gray-300">{Math.round(progress)}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2.5">
                        <div className="bg-indigo-500 h-2.5 rounded-full transition-all duration-300 ease-linear" style={{ width: `${progress}%` }}></div>
                    </div>
                </div>
            )}
            
            {projectionInfo && !isLoading && (
                <div className="mb-6 p-3 bg-gray-700/50 rounded-lg border border-gray-600/50 text-sm">
                    <p className="text-gray-300">{projectionInfo.basis}</p>
                    <p className="text-gray-300">Niveau de confiance : <span className={`font-bold ${projectionInfo.color}`}>{projectionInfo.reliability}</span></p>
                </div>
            )}

            {renderCategorySection('Revenu')}
            {renderCategorySection('Dépense')}
            {renderCategorySection('Épargne')}

            {budgetCategories.length === 0 && (
                <p className="text-gray-400 text-center py-10">Veuillez d'abord ajouter des catégories budgétaires pour commencer la planification.</p>
            )}

            <div className="mt-10">
                <h3 className="text-2xl font-bold text-white mb-4">Récapitulatif Annuel Prévisionnel</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-white">
                    <div className="bg-gray-700 p-4 rounded-lg">
                        <p className="text-sm text-gray-400">Total Revenus</p>
                        <p className="text-2xl font-bold text-green-400">{summaryData.totalIncome.toFixed(2)}{currency}</p>
                    </div>
                    <div className="bg-gray-700 p-4 rounded-lg">
                        <p className="text-sm text-gray-400">Total Dépenses</p>
                        <p className="text-2xl font-bold text-red-400">{summaryData.totalExpenses.toFixed(2)}{currency}</p>
                    </div>
                    <div className="bg-gray-700 p-4 rounded-lg">
                        <p className="text-sm text-gray-400">Total Épargne</p>
                        <p className="text-2xl font-bold text-blue-400">{summaryData.totalSavings.toFixed(2)}{currency}</p>
                    </div>
                     <div className="bg-gray-700 p-4 rounded-lg">
                        <p className="text-sm text-gray-400">Solde Net Final</p>
                        <p className={`text-2xl font-bold ${summaryData.netBalance >= 0 ? 'text-indigo-400' : 'text-orange-400'}`}>{summaryData.netBalance.toFixed(2)}{currency}</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BudgetPlanner;
