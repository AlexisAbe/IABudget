import React, { useState, useContext, useMemo } from 'react';
import { UserContext } from '../../context/UserContext';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#00C49F', '#FFBB28', '#FF8042', '#0088FE'];

const CustomTooltip = ({ active, payload, currency }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-gray-800 p-2 border border-gray-600 rounded shadow-lg">
                <p className="text-white font-bold">{`${payload[0].name}`}</p>
                <p className="text-indigo-400">{`Dépenses: ${payload[0].value?.toFixed(2)} ${currency}`}</p>
            </div>
        );
    }
    return null;
};

const MonthlyDashboard: React.FC = () => {
    const context = useContext(UserContext);
    const [date, setDate] = useState({ month: new Date().getMonth() + 1, year: new Date().getFullYear() });

    const monthlyData = useMemo(() => {
        if (!context) return null;
        const { transactions, budgetPlan, budgetCategories } = context;

        const filteredTransactions = transactions.filter(t => {
            const tDate = new Date(t.date);
            return tDate.getMonth() + 1 === date.month && tDate.getFullYear() === date.year;
        });

        const totalIncome = filteredTransactions.filter(t => t.type === 'credit').reduce((sum, t) => sum + t.amount, 0);
        const totalExpenses = filteredTransactions.filter(t => t.type === 'debit').reduce((sum, t) => sum + t.amount, 0);
        const netSavings = totalIncome - totalExpenses;
        
        const expenseByCategory = filteredTransactions
            .filter(t => t.type === 'debit' && t.category)
            .reduce((acc, t) => {
                const categoryName = t.category!.split(' > ')[0]; // Use parent category for main chart
                if (!acc[categoryName]) {
                    acc[categoryName] = 0;
                }
                acc[categoryName] += t.amount;
                return acc;
            }, {} as Record<string, number>);

        const chartData = Object.entries(expenseByCategory).map(([name, value]) => ({ name, value }));
        
        const budgetComparison = budgetCategories
            .filter(cat => cat.type === 'Dépense')
            .map(cat => {
                const actual = expenseByCategory[cat.name] || 0;
                const plannedItem = budgetPlan.find(p => p.categoryId === cat.id && p.month === date.month && p.year === date.year);
                const planned = plannedItem ? plannedItem.plannedAmount : 0;
                const difference = actual - planned;
                return { name: cat.name, actual, planned, difference };
            })
            .filter(item => item.actual > 0 || item.planned > 0)
            .sort((a,b) => b.actual - a.actual);

        return { totalIncome, totalExpenses, netSavings, chartData, budgetComparison };
    }, [context, date]);

    if (!context) return <div className="text-white">Chargement...</div>;
    const { currency } = context;

    return (
        <div className="bg-gray-800/50 p-6 rounded-2xl shadow-lg">
            <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <h2 className="text-2xl font-bold text-white">Tableau de Bord Mensuel</h2>
                <div className="flex gap-2">
                    <select value={date.month} onChange={e => setDate(d => ({...d, month: parseInt(e.target.value)}))} className="bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500">
                        {Array.from({length: 12}, (_, i) => <option key={i+1} value={i+1}>{new Date(0, i).toLocaleString('fr-FR', { month: 'long' })}</option>)}
                    </select>
                     <select value={date.year} onChange={e => setDate(d => ({...d, year: parseInt(e.target.value)}))} className="bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500">
                        {Array.from(new Set(context.transactions.map(t => new Date(t.date).getFullYear()))).sort((a,b) => b-a).map(y => <option key={y} value={y}>{y}</option>)}
                    </select>
                </div>
            </div>

            {monthlyData ? (
                <>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div className="bg-gray-700 p-4 rounded-lg text-center"><p className="text-sm text-gray-400">Revenus</p><p className="text-2xl font-bold text-green-400">{monthlyData.totalIncome.toFixed(2)}{currency}</p></div>
                        <div className="bg-gray-700 p-4 rounded-lg text-center"><p className="text-sm text-gray-400">Dépenses</p><p className="text-2xl font-bold text-red-400">{monthlyData.totalExpenses.toFixed(2)}{currency}</p></div>
                        <div className="bg-gray-700 p-4 rounded-lg text-center"><p className="text-sm text-gray-400">Solde Net</p><p className={`text-2xl font-bold ${monthlyData.netSavings >= 0 ? 'text-blue-400' : 'text-orange-400'}`}>{monthlyData.netSavings.toFixed(2)}{currency}</p></div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="bg-gray-700/50 p-4 rounded-lg">
                             <h3 className="font-bold text-white mb-4">Répartition des Dépenses</h3>
                            <div style={{ width: '100%', height: 300 }}>
                                <ResponsiveContainer>
                                    <PieChart>
                                        <Pie data={monthlyData.chartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8">
                                            {monthlyData.chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                                        </Pie>
                                        <Tooltip content={<CustomTooltip currency={currency} />} />
                                        <Legend />
                                    </PieChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                        <div className="bg-gray-700/50 p-4 rounded-lg">
                             <h3 className="font-bold text-white mb-4">Dépenses vs. Budget</h3>
                             <div className="max-h-[300px] overflow-y-auto pr-2">
                                {monthlyData.budgetComparison.map((item, index) => (
                                    <div key={index} className="mb-2">
                                        <div className="flex justify-between text-sm font-semibold text-white">
                                            <span>{item.name}</span>
                                            <span>{item.actual.toFixed(2)} / {item.planned > 0 ? item.planned.toFixed(2) : '-'} {currency}</span>
                                        </div>
                                        <div className="w-full bg-gray-600 rounded-full h-2.5 mt-1">
                                            <div className={`h-2.5 rounded-full ${item.difference > 0 ? 'bg-red-500' : 'bg-green-500'}`} style={{ width: `${item.planned > 0 ? Math.min((item.actual/item.planned)*100, 100) : 0}%`}}></div>
                                        </div>
                                         {item.planned > 0 && <p className={`text-xs text-right mt-1 ${item.difference > 0 ? 'text-red-400' : 'text-green-400'}`}>
                                            {item.difference > 0 ? `+${item.difference.toFixed(2)}` : item.difference.toFixed(2)} {currency}
                                        </p>}
                                    </div>
                                ))}
                                {monthlyData.budgetComparison.length === 0 && <p className="text-gray-400 text-center mt-10">Aucune dépense ou budget ce mois-ci.</p>}
                             </div>
                        </div>
                    </div>
                </>
            ) : (
                 <div className="h-64 flex items-center justify-center bg-gray-700/50 rounded-lg">
                    <p className="text-gray-500">Aucune donnée pour cette période.</p>
                </div>
            )}
        </div>
    );
};

export default MonthlyDashboard;