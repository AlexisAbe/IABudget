
import React, { useState, useContext, ChangeEvent, DragEvent } from 'react';
import { UserContext } from '../../context/UserContext';
import { createFinancialPersona, analyzeTransactionsFromFile } from '../../services/geminiService';
import { TrophyIcon, ArrowRightIcon, UploadCloudIcon } from '../icons';
import { Investment } from '../../types';

const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]);
    };
    reader.onerror = error => reject(error);
});


const Onboarding: React.FC = () => {
    const [step, setStep] = useState(1);
    const [name, setName] = useState('');
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [dreams, setDreams] = useState('');
    const [investments, setInvestments] = useState<Omit<Investment, 'id'>[]>([{ name: '', type: 'Fonds d\'urgence', amount: 0 }]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const context = useContext(UserContext);
    
    const handleFileSelect = (file: File | null) => {
        if (file) {
            if (file.type === 'text/csv' || file.type === 'application/pdf') {
                setSelectedFile(file);
                setError('');
            } else {
                setError('Format de fichier non supporté. Veuillez sélectionner un fichier CSV ou PDF.');
                setSelectedFile(null);
            }
        }
    }

    const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
        handleFileSelect(e.target.files?.[0] || null);
    };

    const handleDrop = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        handleFileSelect(e.dataTransfer.files?.[0] || null);
    };

    const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };

    const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
    };

    const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    };

    const handleNext = () => {
        if (step === 1 && name.trim() === '') {
            setError('Veuillez entrer votre prénom.');
            return;
        }
        if (step === 2 && !selectedFile) {
             setError('Veuillez importer un fichier de transactions.');
            return;
        }
        setError('');
        setStep(step + 1);
    };
    
    const handleInvestmentChange = (index: number, field: keyof Omit<Investment, 'id'>, value: string | number) => {
        const newInvestments = [...investments];
        const investmentToUpdate = { ...newInvestments[index] };
        (investmentToUpdate[field as keyof typeof investmentToUpdate] as any) = value;
        newInvestments[index] = investmentToUpdate;
        setInvestments(newInvestments);
    };

    const addInvestmentRow = () => {
        setInvestments([...investments, { name: '', type: 'Épargne long terme', amount: 0 }]);
    };

    const removeInvestmentRow = (index: number) => {
        setInvestments(investments.filter((_, i) => i !== index));
    };

    const handleFinish = async () => {
        if (!context || !selectedFile) return;
        setIsLoading(true);
        setError('');

        try {
            const finalInvestments = investments
                .filter(inv => inv.name && inv.amount > 0)
                .map(inv => ({ ...inv, id: `inv-${Date.now()}-${Math.random()}`}));

            context.setInvestments(finalInvestments);

            const userInfo = `Utilisateur: ${name}. Rêves/Objectifs: ${dreams}.`;
            const personaPromise = createFinancialPersona(userInfo, finalInvestments);

            const fileData = await toBase64(selectedFile);
            const analyzedTransactionsPromise = analyzeTransactionsFromFile(fileData, selectedFile.type);

            const [persona, analyzedTransactions] = await Promise.all([personaPromise, analyzedTransactionsPromise]);
            
            if (!analyzedTransactions || analyzedTransactions.length === 0) {
                throw new Error("L'IA n'a pas pu extraire de transactions de votre fichier. Vérifiez son contenu et son format.");
            }

            context.setTransactions(analyzedTransactions);
            context.saveUserProfile({ name, onboarded: true }, persona);
            
        } catch (e: any) {
            console.error(e);
            setError(e.message || "Une erreur est survenue lors de l'analyse. Veuillez réessayer.");
            setIsLoading(false);
        }
    };
    
    const renderStep = () => {
        switch (step) {
            case 1:
                return (
                    <div>
                        <h2 className="text-3xl font-bold text-white mb-2">Bienvenue sur Pilote Budgétaire IA</h2>
                        <p className="text-lg text-gray-400 mb-8">Commençons par faire connaissance. Quel est votre prénom ?</p>
                        <input
                            type="text"
                            value={name}
                            onChange={(e: ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
                            placeholder="Ex: Alex"
                            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        />
                    </div>
                );
            case 2:
                return (
                    <div>
                        <h2 className="text-3xl font-bold text-white mb-2">Importez vos transactions</h2>
                        <p className="text-lg text-gray-400 mb-4">Importez un fichier CSV ou PDF de vos relevés bancaires.</p>
                        <p className="text-xs text-gray-500 mb-6">Vos données sont traitées de manière sécurisée et ne sont jamais stockées sur nos serveurs.</p>
                        <div 
                            onDrop={handleDrop}
                            onDragOver={handleDragOver}
                            onDragEnter={handleDragEnter}
                            onDragLeave={handleDragLeave}
                            className={`relative border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors duration-300 ${isDragging ? 'border-indigo-500 bg-gray-700' : 'border-gray-600 hover:border-indigo-500'}`}
                        >
                            <input
                                type="file"
                                id="file-upload"
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                onChange={handleFileChange}
                                accept=".csv,.pdf,text/csv,application/pdf"
                            />
                            <label htmlFor="file-upload" className="flex flex-col items-center justify-center space-y-2 cursor-pointer">
                                <UploadCloudIcon className="w-12 h-12 text-gray-400" />
                                {selectedFile ? (
                                    <div>
                                        <p className="text-white font-semibold">{selectedFile.name}</p>
                                        <p className="text-sm text-gray-400">({(selectedFile.size / 1024).toFixed(1)} KB)</p>
                                        <p className="text-xs text-indigo-400 mt-2">Cliquez ou glissez pour changer</p>
                                    </div>
                                ) : (
                                    <div>
                                        <p className="font-semibold text-white">Glissez-déposez un fichier ou <span className="text-indigo-400">cliquez pour choisir</span></p>
                                        <p className="text-sm text-gray-400">CSV ou PDF acceptés</p>
                                    </div>
                                )}
                            </label>
                        </div>
                    </div>
                );
            case 3:
                return (
                     <div>
                        <h2 className="text-3xl font-bold text-white mb-2">Quels sont vos rêves ?</h2>
                        <p className="text-lg text-gray-400 mb-8">Décrivez en quelques mots vos grands objectifs financiers. (Ex: "acheter une maison dans 5 ans, voyager en Asie, mettre 10k€ de côté pour les urgences")</p>
                        <textarea
                            value={dreams}
                            onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setDreams(e.target.value)}
                            placeholder="Décrivez vos ambitions..."
                            className="w-full h-32 bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        />
                    </div>
                );
            case 4:
                return (
                    <div>
                        <h2 className="text-3xl font-bold text-white mb-2">Votre patrimoine (Optionnel)</h2>
                        <p className="text-lg text-gray-400 mb-6">Pour des conseils plus pertinents, indiquez vos placements actuels. Vous pouvez sauter cette étape.</p>
                        <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                            {investments.map((inv, index) => (
                                <div key={index} className="flex items-center gap-2">
                                    <input type="text" placeholder="Nom (ex: Livret A)" value={inv.name} onChange={e => handleInvestmentChange(index, 'name', e.target.value)} className="w-1/3 bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500" />
                                    <select value={inv.type} onChange={e => handleInvestmentChange(index, 'type', e.target.value)} className="w-1/3 bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500">
                                        <option>Fonds d'urgence</option>
                                        <option>Épargne long terme</option>
                                        <option>Autre</option>
                                    </select>
                                    <input type="number" placeholder="Montant €" value={inv.amount || ''} onChange={e => handleInvestmentChange(index, 'amount', parseFloat(e.target.value) || 0)} className="w-1/3 bg-gray-700 border-gray-600 rounded px-2 py-1.5 text-white focus:ring-1 focus:ring-indigo-500" />
                                    <button type="button" onClick={() => removeInvestmentRow(index)} className="text-red-400 hover:text-red-600 p-1">&times;</button>
                                </div>
                            ))}
                        </div>
                        <button type="button" onClick={addInvestmentRow} className="text-indigo-400 hover:text-indigo-300 text-sm mt-3">+ Ajouter un placement</button>
                    </div>
                );
            case 5:
                return (
                    <div>
                        <h2 className="text-3xl font-bold text-white mb-2">Prêt à décoller ?</h2>
                        <p className="text-lg text-gray-400 mb-8">Nous allons maintenant analyser vos données pour créer votre cockpit financier personnalisé. Cela peut prendre un instant.</p>
                        <TrophyIcon className="w-24 h-24 text-yellow-400 mx-auto" />
                    </div>
                )
        }
    };
    
    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-900 p-4">
            <div className="w-full max-w-2xl bg-gray-800 shadow-2xl rounded-2xl p-8 transition-all duration-500">
                <div className="mb-8">
                    <div className="flex justify-between items-center">
                         <span className="text-sm font-semibold text-indigo-400">ÉTAPE {step} / 5</span>
                         <div className="flex space-x-2">
                            <div className={`w-8 h-2 rounded-full ${step >= 1 ? 'bg-indigo-500' : 'bg-gray-700'}`}></div>
                            <div className={`w-8 h-2 rounded-full ${step >= 2 ? 'bg-indigo-500' : 'bg-gray-700'}`}></div>
                            <div className={`w-8 h-2 rounded-full ${step >= 3 ? 'bg-indigo-500' : 'bg-gray-700'}`}></div>
                            <div className={`w-8 h-2 rounded-full ${step >= 4 ? 'bg-indigo-500' : 'bg-gray-700'}`}></div>
                            <div className={`w-8 h-2 rounded-full ${step >= 5 ? 'bg-indigo-500' : 'bg-gray-700'}`}></div>
                         </div>
                    </div>
                </div>

                <div className="min-h-[250px]">
                    {isLoading ? (
                         <div className="flex flex-col items-center justify-center h-full">
                            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-400"></div>
                            <p className="text-gray-300 mt-4">L'IA prépare votre cockpit...</p>
                         </div>
                    ) : renderStep()}
                </div>
                
                {error && <p className="text-red-400 text-sm mt-4">{error}</p>}
                
                <div className="mt-8">
                    {step < 5 ? (
                        <button onClick={handleNext} className="w-full flex items-center justify-center bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300 disabled:opacity-50">
                            <span>{step === 4 ? 'Suivant (ou sauter)' : 'Suivant'}</span>
                            <ArrowRightIcon className="w-5 h-5 ml-2" />
                        </button>
                    ) : (
                         <button onClick={handleFinish} disabled={isLoading} className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed">
                            {isLoading ? 'Analyse en cours...' : 'Créer mon cockpit'}
                        </button>
                    )}
                </div>
            </div>
        </div>
    )
}

export default Onboarding;
