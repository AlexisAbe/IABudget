import React, { useContext, useState, useMemo } from 'react';
import { UserContext } from '../../context/UserContext';
import { ActionItem, Transaction, ActionableTransaction } from '../../types';
import { ClipboardCheckIcon, CheckCircleIcon, Trash2Icon, ChevronDownIcon, ChevronUpIcon } from '../icons';

interface ActionItemCardProps {
    item: ActionItem;
    transactions: Transaction[];
    isExpanded: boolean;
    onToggleExpand: () => void;
}

const ActionItemCard: React.FC<ActionItemCardProps> = ({ item, transactions, isExpanded, onToggleExpand }) => {
    const context = useContext(UserContext);
    if (!context) return null;

    const { updateActionItem, deleteActionItem, updateActionableTransactionStatus } = context;

    const relatedTransactionsWithStatus = useMemo(() => {
        if (!item.relatedTransactions) return [];
        return item.relatedTransactions.map(rt => {
            const transaction = transactions.find(t => t.id === rt.transactionId);
            return {
                ...transaction,
                id: rt.transactionId, // Ensure ID is present even if transaction is not found
                actionStatus: rt.status,
            };
        }).filter(t => t.description); // Filter out any not found
    }, [item.relatedTransactions, transactions]);
    
    const hasTransactions = relatedTransactionsWithStatus.length > 0;

    return (
        <div className={`rounded-xl transition-all duration-300 ${item.status === 'done' ? 'bg-gray-800/50' : 'bg-gray-800'}`}>
            <div className="p-5">
                <div className="flex items-start gap-4">
                    <button onClick={() => updateActionItem(item.id, { status: item.status === 'todo' ? 'done' : 'todo' })} className="mt-1 flex-shrink-0">
                        {item.status === 'done' ? <CheckCircleIcon className="w-6 h-6 text-green-500" /> : <div className="w-6 h-6 rounded-full border-2 border-gray-500 hover:border-indigo-400" />}
                    </button>
                    <div className="flex-grow">
                        <h4 className={`font-bold text-lg ${item.status === 'done' ? 'text-gray-500 line-through' : 'text-white'}`}>{item.title}</h4>
                        <p className={`text-sm ${item.status === 'done' ? 'text-gray-600' : 'text-gray-400'}`}>{item.description}</p>
                        <div className="mt-2 flex items-center gap-4 text-xs">
                            <span className="bg-indigo-900/70 text-indigo-300 px-2 py-0.5 rounded-full capitalize">{item.actionType}</span>
                            <span className="text-green-400 font-semibold">Économie potentielle : {item.potentialSaving}€</span>
                            {hasTransactions && <span className="text-gray-500">{relatedTransactionsWithStatus.length} transaction(s) liée(s)</span>}
                        </div>
                    </div>
                    <div className="flex flex-col items-center gap-4">
                         <button onClick={() => deleteActionItem(item.id)} className="text-gray-600 hover:text-red-500 flex-shrink-0">
                            <Trash2Icon className="w-5 h-5" />
                        </button>
                        {hasTransactions && (
                            <button onClick={onToggleExpand} className="text-gray-500 hover:text-indigo-400">
                                {isExpanded ? <ChevronUpIcon className="w-5 h-5" /> : <ChevronDownIcon className="w-5 h-5" />}
                            </button>
                        )}
                    </div>
                </div>
            </div>
            {isExpanded && hasTransactions && (
                <div className="px-5 pb-5 mt-2 border-t border-gray-700/50">
                    <h5 className="font-semibold text-white mt-4 mb-2">Transactions liées ({relatedTransactionsWithStatus.length})</h5>
                     <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                        {relatedTransactionsWithStatus.map(t => (
                            <div key={t.id} className="flex justify-between items-center bg-gray-700/50 p-2 rounded-lg">
                                <div>
                                    <p className="font-medium text-sm text-white">{t.description}</p>
                                    <p className="text-xs text-gray-400">{t.date ? new Date(t.date).toLocaleDateString() : 'Date N/A'}</p>
                                </div>
                                <div className="flex items-center gap-4">
                                    <p className="font-mono text-sm text-red-400">-{t.amount?.toFixed(2)}€</p>
                                    <select
                                        value={t.actionStatus}
                                        onChange={(e) => updateActionableTransactionStatus(item.id, t.id, e.target.value as ActionableTransaction['status'])}
                                        onClick={(e) => e.stopPropagation()}
                                        className="bg-gray-900 border border-gray-600 rounded-md text-xs text-white p-1 focus:ring-1 focus:ring-indigo-500"
                                    >
                                        <option value="none">Aucune action</option>
                                        <option value="reduce">Réduire</option>
                                        <option value="eliminate">Supprimer</option>
                                        <option value="challenge">Challenger</option>
                                    </select>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};


const ActionPlanView: React.FC = () => {
    const context = useContext(UserContext);
    const [expandedItemId, setExpandedItemId] = useState<string | null>(null);

    if (!context) return null;

    const { actionItems, transactions } = context;
    const todoItems = actionItems.filter(item => item.status === 'todo');
    const doneItems = actionItems.filter(item => item.status === 'done');
    
    const handleToggleExpand = (itemId: string) => {
        setExpandedItemId(prevId => (prevId === itemId ? null : itemId));
    };

    return (
        <div>
            <h2 className="text-3xl font-bold text-white flex items-center mb-6">
                <ClipboardCheckIcon className="w-8 h-8 mr-3 text-indigo-400" />
                Mon Plan d'Action
            </h2>

            {actionItems.length === 0 ? (
                <div className="text-center py-16 bg-gray-800/50 rounded-2xl">
                    <p className="text-gray-400">Votre plan d'action est vide.</p>
                    <p className="text-gray-500 text-sm">Cliquez sur les analyses IA dans le Cockpit pour ajouter des points d'action.</p>
                </div>
            ) : (
                <div className="space-y-8">
                    <div>
                        <h3 className="text-xl font-semibold text-white mb-4">À Faire</h3>
                        {todoItems.length > 0 ? (
                            <div className="space-y-4">
                                {todoItems.map(item => (
                                    <ActionItemCard 
                                        key={item.id} 
                                        item={item}
                                        transactions={transactions}
                                        isExpanded={expandedItemId === item.id}
                                        onToggleExpand={() => handleToggleExpand(item.id)}
                                    />
                                ))}
                            </div>
                        ) : <p className="text-gray-500 p-4 bg-gray-800/50 rounded-lg">Rien à faire pour le moment. Bravo !</p>}
                    </div>
                    <div>
                        <h3 className="text-xl font-semibold text-white mb-4">Terminé</h3>
                        {doneItems.length > 0 ? (
                             <div className="space-y-4">
                                {doneItems.map(item => (
                                    <ActionItemCard 
                                        key={item.id} 
                                        item={item} 
                                        transactions={transactions}
                                        isExpanded={expandedItemId === item.id}
                                        onToggleExpand={() => handleToggleExpand(item.id)}
                                    />
                                ))}
                            </div>
                        ) : <p className="text-gray-500 p-4 bg-gray-800/50 rounded-lg">Aucune action terminée.</p>}
                    </div>
                </div>
            )}
        </div>
    );
};

export default ActionPlanView;