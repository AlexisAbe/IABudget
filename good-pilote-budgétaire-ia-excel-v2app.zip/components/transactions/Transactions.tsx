import React, { useContext, useState, useMemo, ChangeEvent } from 'react';
import { UserContext } from '../../context/UserContext';
import { ReceiptPercentIcon } from '../icons';
import { Transaction } from '../../types';

const PREDEFINED_CATEGORIES = ['Courses', 'Restaurant', 'Transport', 'Loyer', 'Salaire', 'Abonnements', 'Shopping', 'Santé', 'Loisirs', 'Épargne'];

const Transactions: React.FC = () => {
    const context = useContext(UserContext);
    const [filter, setFilter] = useState('');
    const [sort, setSort] = useState({ key: 'date', order: 'desc' });
    const [editingId, setEditingId] = useState<string | null>(null);

    const transactions = context?.transactions || [];

    const availableCategories = useMemo(() => {
        const dynamicCategories = transactions.map(t => t.category).filter(Boolean) as string[];
        const budgetCategoryNames = context?.budgetCategories.map(c => c.name) || [];
        return [...new Set([...PREDEFINED_CATEGORIES, ...dynamicCategories, ...budgetCategoryNames])].sort();
    }, [transactions, context?.budgetCategories]);

    const sortedAndFilteredTransactions = useMemo(() => {
        return transactions
            .filter(t => t.description.toLowerCase().includes(filter.toLowerCase()) || t.category?.toLowerCase().includes(filter.toLowerCase()))
            .sort((a, b) => {
                const aVal = a[sort.key as keyof typeof a];
                const bVal = b[sort.key as keyof typeof b];

                if (aVal === undefined) return 1;
                if (bVal === undefined) return -1;

                if (aVal < bVal) return sort.order === 'asc' ? -1 : 1;
                if (aVal > bVal) return sort.order === 'asc' ? 1 : -1;
                return 0;
            });
    }, [transactions, filter, sort]);

    const handleSort = (key: string) => {
        if (sort.key === key) {
            setSort({ key, order: sort.order === 'asc' ? 'desc' : 'asc' });
        } else {
            setSort({ key, order: 'desc' });
        }
    };

    const handleCategoryChange = (e: ChangeEvent<HTMLSelectElement>, transaction: Transaction) => {
        context?.updateTransaction({ ...transaction, category: e.target.value });
        setEditingId(null);
    };

    const getSortIndicator = (key: string) => {
        if (sort.key !== key) return '↕';
        return sort.order === 'desc' ? '↓' : '↑';
    };

    return (
        <div>
            <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                <h2 className="text-3xl font-bold text-white flex items-center">
                    <ReceiptPercentIcon className="w-8 h-8 mr-3 text-indigo-400" />
                    Historique des Transactions
                </h2>
                <input
                    type="text"
                    placeholder="Filtrer par description ou catégorie..."
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                    className="bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
            </div>

            <div className="bg-gray-800 rounded-xl shadow-lg overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-700/50">
                            <tr>
                                <th scope="col" className="px-6 py-3 cursor-pointer" onClick={() => handleSort('date')}>Date {getSortIndicator('date')}</th>
                                <th scope="col" className="px-6 py-3 cursor-pointer" onClick={() => handleSort('description')}>Description {getSortIndicator('description')}</th>
                                <th scope="col" className="px-6 py-3 cursor-pointer" onClick={() => handleSort('category')}>Catégorie {getSortIndicator('category')}</th>
                                <th scope="col" className="px-6 py-3 text-right cursor-pointer" onClick={() => handleSort('amount')}>Montant {getSortIndicator('amount')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedAndFilteredTransactions.map(t => (
                                <tr key={t.id} className="bg-gray-800 border-b border-gray-700 hover:bg-gray-700/50">
                                    <td className="px-6 py-4 whitespace-nowrap">{new Date(t.date).toLocaleDateString('fr-FR')}</td>
                                    <td className="px-6 py-4 font-medium text-white">{t.description}</td>
                                    <td className="px-6 py-4" onClick={() => setEditingId(t.id)}>
                                        {editingId === t.id ? (
                                            <select
                                                value={t.category || ''}
                                                onChange={(e) => handleCategoryChange(e, t)}
                                                onBlur={() => setEditingId(null)}
                                                className="bg-gray-900 border-gray-600 text-white focus:ring-indigo-500 focus:border-indigo-500 rounded-md"
                                                autoFocus
                                            >
                                                <option value="">Non classé</option>
                                                {availableCategories.map(cat => (
                                                    <option key={cat} value={cat}>{cat}</option>
                                                ))}
                                            </select>
                                        ) : (
                                            <span className={`px-2 py-1 text-xs font-medium rounded-full cursor-pointer ${t.isRecurring ? 'bg-purple-900 text-purple-300' : 'bg-gray-700 text-gray-300'}`}>
                                                {t.category || 'N/A'}
                                            </span>
                                        )}
                                    </td>
                                    <td className={`px-6 py-4 text-right font-mono ${t.type === 'credit' ? 'text-green-400' : 'text-red-400'}`}>
                                        {t.type === 'credit' ? '+' : '-'}{t.amount.toFixed(2)}€
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {sortedAndFilteredTransactions.length === 0 && (
                 <p className="text-center text-gray-400 mt-8">Aucune transaction à afficher.</p>
            )}
        </div>
    );
};

export default Transactions;