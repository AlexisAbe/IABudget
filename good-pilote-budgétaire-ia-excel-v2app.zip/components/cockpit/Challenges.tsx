import React, { useContext, useEffect, useState } from 'react';
import { UserContext } from '../../context/UserContext';
import { generateChallenges } from '../../services/geminiService';
import { TrophyIcon } from '../icons';
import ActionableInsightModal from './ActionableInsightModal';
import { Challenge } from '../../types';

const Challenges: React.FC = () => {
    const context = useContext(UserContext);
    const [isLoading, setIsLoading] = useState(false);
    const [selectedChallenge, setSelectedChallenge] = useState<Challenge | null>(null);

    useEffect(() => {
        const fetchChallenges = async () => {
            if (context && context.persona && context.transactions.length > 0 && context.challenges.length === 0) {
                setIsLoading(true);
                try {
                    const newChallenges = await generateChallenges(context.persona, context.transactions);
                    context.setChallenges(newChallenges);
                } catch (error) {
                    console.error("Failed to generate challenges:", error);
                } finally {
                    setIsLoading(false);
                }
            }
        };

        // eslint-disable-next-line react-hooks/exhaustive-deps
        fetchChallenges();
    }, [context?.persona, context?.transactions]);

    if (!context) return null;

    const { challenges } = context;

    return (
        <>
            {selectedChallenge && (
                <ActionableInsightModal
                    isOpen={!!selectedChallenge}
                    onClose={() => setSelectedChallenge(null)}
                    insightTitle={selectedChallenge.title}
                    insightDescription={selectedChallenge.description}
                    potentialSaving={selectedChallenge.reward}
                />
            )}
            <div className="bg-gray-800 p-6 rounded-2xl shadow-lg h-full">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                    <TrophyIcon className="w-6 h-6 text-yellow-400 mr-3" />
                    Vos Missions du Mois
                </h3>
                {isLoading && (
                    <div className="space-y-4">
                        {[...Array(3)].map((_, i) => (
                            <div key={i} className="flex items-center space-x-4 p-3 bg-gray-700/50 rounded-lg animate-pulse">
                                <div className="w-10 h-10 bg-gray-600 rounded-lg"></div>
                                <div className="flex-1 space-y-2">
                                    <div className="h-4 bg-gray-600 rounded w-3/4"></div>
                                    <div className="h-3 bg-gray-600 rounded w-1/2"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
                {!isLoading && challenges.length === 0 && (
                    <p className="text-gray-400">Aucune mission pour le moment. Revenez plus tard !</p>
                )}
                {!isLoading && challenges.length > 0 && (
                    <div className="space-y-4">
                        {challenges.map(challenge => (
                            <button
                                key={challenge.id}
                                onClick={() => setSelectedChallenge(challenge)}
                                className="w-full text-left bg-gray-700/50 p-4 rounded-xl transition-transform hover:scale-105 duration-300"
                            >
                               <div className="flex items-start space-x-4">
                                   <div className="text-3xl mt-1">{challenge.emoji}</div>
                                   <div>
                                       <p className="font-semibold text-white">{challenge.title}</p>
                                       <p className="text-sm text-gray-400">{challenge.description}</p>
                                       <p className="text-sm font-bold text-green-400 mt-1">Économie potentielle : {challenge.reward}€</p>
                                   </div>
                               </div>
                            </button>
                        ))}
                    </div>
                )}
            </div>
        </>
    );
};

export default Challenges;