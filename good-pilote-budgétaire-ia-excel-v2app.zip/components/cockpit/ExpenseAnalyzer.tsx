import React, { useState } from 'react';
import { Transaction, SpendingHabitAnalysis } from '../../types';
import { analyzeSpendingHabits } from '../../services/geminiService';
import { SparklesIcon } from '../icons';
import ActionableInsightModal from './ActionableInsightModal';

interface ExpenseAnalyzerProps {
    transactions: Transaction[];
}

const ExpenseAnalyzer: React.FC<ExpenseAnalyzerProps> = ({ transactions }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [analysis, setAnalysis] = useState<SpendingHabitAnalysis[] | null>(null);
    const [error, setError] = useState('');
    const [selectedHabit, setSelectedHabit] = useState<SpendingHabitAnalysis | null>(null);

    const handleAnalyze = async () => {
        setIsLoading(true);
        setError('');
        setAnalysis(null);
        try {
            const result = await analyzeSpendingHabits(transactions);
            if (result.length === 0) {
                 setError("L'IA n'a pas trouvé de points d'optimisation clairs pour cette période.");
            }
            setAnalysis(result);
        } catch (e) {
            console.error("Failed to analyze spending habits", e);
            setError("Une erreur est survenue lors de l'analyse IA.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <>
             {selectedHabit && (
                <ActionableInsightModal
                    isOpen={!!selectedHabit}
                    onClose={() => setSelectedHabit(null)}
                    insightTitle={selectedHabit.category}
                    insightDescription={selectedHabit.suggestion}
                    potentialSaving={selectedHabit.potentialSaving}
                />
            )}
            <div className="bg-gray-800 p-6 rounded-2xl shadow-lg">
                <div className="flex flex-col md:flex-row justify-between md:items-center mb-4">
                    <h3 className="text-xl font-bold text-white flex items-center mb-3 md:mb-0">
                        <SparklesIcon className="w-6 h-6 text-yellow-400 mr-3" />
                        Analyse IA de vos habitudes
                    </h3>
                    <button
                        onClick={handleAnalyze}
                        disabled={isLoading || transactions.filter(t=>t.type==='debit').length === 0}
                        className="bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-bold py-2 px-5 rounded-lg transition duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                        {isLoading ? (
                            <>
                                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-gray-900 mr-2"></div>
                                Analyse en cours...
                            </>
                        ) : 'Analyser la période'}
                    </button>
                </div>
                
                 {transactions.filter(t=>t.type==='debit').length === 0 && !analysis && (
                    <p className="text-center text-gray-500 py-4">Aucune dépense à analyser sur cette période.</p>
                )}

                {isLoading && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                        {[...Array(3)].map((_, i) => (
                            <div key={i} className="bg-gray-700/50 p-4 rounded-xl animate-pulse">
                                <div className="h-5 bg-gray-600 rounded w-1/2 mb-3"></div>
                                <div className="h-4 bg-gray-600 rounded w-full mb-2"></div>
                                <div className="h-4 bg-gray-600 rounded w-3/4"></div>
                            </div>
                        ))}
                    </div>
                )}

                {error && !isLoading && <p className="text-yellow-400 text-center py-4">{error}</p>}
                
                {analysis && analysis.length > 0 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                        {analysis.map(item => (
                            <button
                                key={item.id}
                                onClick={() => setSelectedHabit(item)}
                                className="w-full text-left bg-gray-700/80 p-5 rounded-xl border border-gray-600/50 hover:ring-2 hover:ring-yellow-500 transition-all"
                            >
                                <div className="flex justify-between items-start">
                                    <h4 className="font-bold text-white text-lg">{item.category}</h4>
                                    <span className="font-mono text-base text-red-400">-{item.amount.toFixed(2)}€</span>
                                </div>
                                <p className="text-sm text-gray-300 mt-2">{item.description}</p>
                                <p className="text-sm text-green-400 mt-3 bg-green-900/30 p-2 rounded-md border border-green-500/20">
                                    <span className="font-bold">Suggestion:</span> {item.suggestion}
                                </p>
                            </button>
                        ))}
                    </div>
                )}
            </div>
        </>
    );
};

export default ExpenseAnalyzer;