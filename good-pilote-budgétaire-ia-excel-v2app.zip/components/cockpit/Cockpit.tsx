import React, { useContext, useMemo, useState, DragEvent, ChangeEvent } from 'react';
import { UserContext } from '../../context/UserContext';
import { Transaction } from '../../types';
import CockpitSkeleton from './CockpitSkeleton';
import Challenges from './Challenges';
import ExpenseAnalyzer from './ExpenseAnalyzer';
import { Treemap, ResponsiveContainer, Tooltip } from 'recharts';
import { CalendarDaysIcon, UploadCloudIcon } from '../icons';
import { analyzeTransactionsFromFile } from '../../services/geminiService';

const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]);
    };
    reader.onerror = error => reject(error);
});

const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-gray-800 p-2 border border-gray-600 rounded shadow-lg">
                <p className="text-white font-bold">{`${payload[0].payload.name}`}</p>
                <p className="text-indigo-400">{`Dépenses: ${payload[0].value?.toFixed(2)} €`}</p>
            </div>
        );
    }
    return null;
};

const AddSupplementaryTransactionsModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const context = useContext(UserContext);
    const [step, setStep] = useState(1);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [supplementaryTransactions, setSupplementaryTransactions] = useState<Transaction[]>([]);
    const [transactionToReplaceId, setTransactionToReplaceId] = useState<string>('');
    const [searchTerm, setSearchTerm] = useState('');

    const handleFileSelect = (file: File | null) => {
        if (file && (file.type === 'text/csv' || file.type === 'application/pdf')) {
            setSelectedFile(file);
            setError('');
        } else {
            setError('Format non supporté. Veuillez choisir un CSV ou PDF.');
            setSelectedFile(null);
        }
    };

    const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => handleFileSelect(e.target.files?.[0] || null);
    const handleDrop = (e: DragEvent<HTMLDivElement>) => { e.preventDefault(); e.stopPropagation(); setIsDragging(false); handleFileSelect(e.dataTransfer.files?.[0] || null); };
    const handleDragOver = (e: DragEvent<HTMLDivElement>) => e.preventDefault();
    const handleDragEnter = () => setIsDragging(true);
    const handleDragLeave = () => setIsDragging(false);

    const handleAnalyzeFile = async () => {
        if (!selectedFile) {
            setError('Veuillez sélectionner un fichier.');
            return;
        }
        setIsLoading(true);
        setError('');
        try {
            const fileData = await toBase64(selectedFile);
            const analyzed = await analyzeTransactionsFromFile(fileData, selectedFile.type);
            if (!analyzed || analyzed.length === 0) throw new Error("L'IA n'a pu extraire aucune transaction.");
            setSupplementaryTransactions(analyzed);
            setStep(2);
        } catch (e: any) {
            setError(e.message || "Erreur lors de l'analyse du fichier.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleConfirmReplacement = () => {
        if (!transactionToReplaceId || !context) {
            setError('Veuillez sélectionner une transaction à remplacer.');
            return;
        }
        context.addSupplementaryTransactions(supplementaryTransactions, transactionToReplaceId);
        onClose();
    };
    
    const potentialReplacements = context?.transactions
        .filter(t => t.type === 'debit' && t.description.toLowerCase().includes(searchTerm.toLowerCase()))
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()) || [];

    return (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
            <div className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
                <div className="p-6 border-b border-gray-700">
                    <h2 className="text-2xl font-bold text-white">Ajouter des dépenses détaillées</h2>
                    <p className="text-sm text-gray-400">Remplacez un paiement global (ex: Amex) par son relevé détaillé.</p>
                </div>

                <div className="p-6 overflow-y-auto">
                    {step === 1 && (
                        <div>
                            <p className="text-lg text-gray-300 mb-4">1. Importez le relevé détaillé (ex: relevé Amex)</p>
                             <div onDrop={handleDrop} onDragOver={handleDragOver} onDragEnter={handleDragEnter} onDragLeave={handleDragLeave} className={`relative border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors duration-300 ${isDragging ? 'border-indigo-500 bg-gray-700' : 'border-gray-600 hover:border-indigo-500'}`}>
                                <input type="file" id="file-upload-modal" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" onChange={handleFileChange} accept=".csv,.pdf" />
                                <label htmlFor="file-upload-modal" className="flex flex-col items-center justify-center space-y-2 cursor-pointer">
                                    <UploadCloudIcon className="w-12 h-12 text-gray-400" />
                                    {selectedFile ? <p className="text-white font-semibold">{selectedFile.name}</p> : <p className="font-semibold text-white">Glissez-déposez ou <span className="text-indigo-400">cliquez</span></p>}
                                </label>
                            </div>
                        </div>
                    )}
                    {step === 2 && (
                        <div>
                            <p className="text-lg text-gray-300 mb-2">2. Sélectionnez le paiement global à remplacer</p>
                            <p className="text-sm text-gray-500 mb-4">{supplementaryTransactions.length} transactions ont été trouvées dans le fichier.</p>
                            <input type="text" placeholder="Rechercher une transaction..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full bg-gray-700 border-gray-600 rounded-lg px-3 py-2 mb-4 text-white" />
                            <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                                {potentialReplacements.map(t => (
                                    <div key={t.id} onClick={() => setTransactionToReplaceId(t.id)} className={`flex justify-between p-3 rounded-lg cursor-pointer ${transactionToReplaceId === t.id ? 'bg-indigo-600 ring-2 ring-indigo-400' : 'bg-gray-700/50 hover:bg-gray-600'}`}>
                                        <div>
                                            <p className="font-semibold">{t.description}</p>
                                            <p className="text-sm text-gray-400">{new Date(t.date).toLocaleDateString()}</p>
                                        </div>
                                        <p className="font-mono text-red-400">-{t.amount.toFixed(2)}€</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                    {error && <p className="text-red-400 text-sm mt-4">{error}</p>}
                </div>

                <div className="p-6 mt-auto border-t border-gray-700 flex justify-end gap-3">
                    <button onClick={onClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-lg">Annuler</button>
                    {step === 1 && <button onClick={handleAnalyzeFile} disabled={!selectedFile || isLoading} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-lg disabled:opacity-50">{isLoading ? 'Analyse...' : 'Suivant'}</button>}
                    {step === 2 && <button onClick={handleConfirmReplacement} disabled={!transactionToReplaceId} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg disabled:opacity-50">Confirmer</button>}
                </div>
            </div>
        </div>
    );
};

const Cockpit: React.FC = () => {
    const context = useContext(UserContext);
    const [period, setPeriod] = useState<'month' | 'year' | 'all' | 'custom'>('month');
    const [customRange, setCustomRange] = useState({ start: '', end: '' });
    const [isModalOpen, setIsModalOpen] = useState(false);

    const filteredTransactions = useMemo(() => {
        if (!context) return [];
        const { transactions } = context;
        const now = new Date();

        switch (period) {
            case 'month':
                return transactions.filter(t => new Date(t.date).getMonth() === now.getMonth() && new Date(t.date).getFullYear() === now.getFullYear());
            case 'year':
                return transactions.filter(t => new Date(t.date).getFullYear() === now.getFullYear());
            case 'custom':
                if (!customRange.start || !customRange.end) return [];
                const start = new Date(customRange.start).getTime();
                const end = new Date(customRange.end).getTime();
                return transactions.filter(t => {
                    const tDate = new Date(t.date).getTime();
                    return tDate >= start && tDate <= end;
                });
            case 'all':
            default:
                return transactions;
        }
    }, [context, period, customRange]);

    const financialData = useMemo(() => {
        if (!context || filteredTransactions.length === 0) {
            return { totalIncome: 0, totalExpenses: 0, savingsRate: 0, expenseByCategory: [] };
        }

        const totalIncome = filteredTransactions.filter(t => t.type === 'credit').reduce((sum, t) => sum + t.amount, 0);
        const totalExpenses = filteredTransactions.filter(t => t.type === 'debit').reduce((sum, t) => sum + t.amount, 0);
        const savingsRate = totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome) * 100 : 0;
        
        const expenseByCategory = filteredTransactions
            .filter(t => t.type === 'debit' && t.category)
            .reduce((acc, t) => {
                const category = t.category!;
                if (!acc[category]) acc[category] = 0;
                acc[category] += t.amount;
                return acc;
            }, {} as Record<string, number>);

        const treemapData = Object.entries(expenseByCategory).map(([name, size]) => ({ name, size }));

        return { totalIncome, totalExpenses, savingsRate, expenseByCategory: treemapData };
    }, [context, filteredTransactions]);

    if (!context || context.loading) return <CockpitSkeleton />;
    if (!context.persona) return <div className="text-center"><p>Veuillez compléter l'onboarding.</p></div>;

    const { totalIncome, totalExpenses, savingsRate, expenseByCategory } = financialData;
    const netSavings = totalIncome - totalExpenses;
    const kpiData = [
        { title: "Revenus", value: `${totalIncome.toFixed(2)}€`, color: "text-green-400" },
        { title: "Dépenses", value: `${totalExpenses.toFixed(2)}€`, color: "text-red-400" },
        { title: "Épargne Nette", value: `${netSavings.toFixed(2)}€`, color: netSavings >= 0 ? "text-blue-400" : "text-orange-400" },
        { title: "Taux d'épargne", value: `${savingsRate.toFixed(1)}%`, color: "text-indigo-400" }
    ];

    return (
        <div>
            {isModalOpen && <AddSupplementaryTransactionsModal onClose={() => setIsModalOpen(false)} />}
            <div className="mb-6">
                <h2 className="text-3xl font-bold text-white">Bonjour {context.userProfile?.name},</h2>
                <p className="text-lg text-gray-400">Votre persona: <span className="font-semibold text-indigo-400">{context.persona.title}</span>.</p>
            </div>

            <div className="mb-6 p-4 bg-gray-800/50 rounded-xl flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-2">
                    {['month', 'year', 'all', 'custom'].map(p => (
                        <button key={p} onClick={() => setPeriod(p as any)} className={`px-3 py-1.5 text-sm font-semibold rounded-lg transition-colors ${period === p ? 'bg-indigo-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}>
                            {p === 'month' && 'Ce mois'}
                            {p === 'year' && 'Cette année'}
                            {p === 'all' && 'Tout'}
                            {p === 'custom' && <span className="flex items-center"><CalendarDaysIcon className="w-4 h-4 mr-1.5" />Personnalisé</span>}
                        </button>
                    ))}
                </div>
                {period === 'custom' && (
                    <div className="flex items-center gap-2">
                        <input type="date" value={customRange.start} onChange={e => setCustomRange(r => ({ ...r, start: e.target.value }))} className="bg-gray-700 border-gray-600 rounded-md px-2 py-1 text-sm" />
                        <span className="text-gray-400">à</span>
                        <input type="date" value={customRange.end} onChange={e => setCustomRange(r => ({ ...r, end: e.target.value }))} className="bg-gray-700 border-gray-600 rounded-md px-2 py-1 text-sm" />
                    </div>
                )}
                 <button onClick={() => setIsModalOpen(true)} className="px-3 py-1.5 text-sm font-semibold rounded-lg transition-colors bg-purple-600 text-white hover:bg-purple-700">
                    Ajouter des dépenses détaillées
                </button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-8">
                {kpiData.map(kpi => (
                     <div key={kpi.title} className="bg-gray-800 p-4 rounded-2xl shadow-lg">
                        <p className="text-sm text-gray-400 mb-1">{kpi.title}</p>
                        <p className={`text-2xl lg:text-3xl font-bold ${kpi.color}`}>{kpi.value}</p>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-gray-800 p-6 rounded-2xl shadow-lg">
                    <h3 className="text-xl font-bold text-white mb-4">Répartition des Dépenses</h3>
                    <div className="w-full h-96">
                       {expenseByCategory.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                                <Treemap data={expenseByCategory} dataKey="size" aspectRatio={4 / 3} stroke="#1f2937" fill="#8884d8" content={<CustomizedContent colors={['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#00C49F']} />}>
                                    <Tooltip content={<CustomTooltip />} />
                                </Treemap>
                            </ResponsiveContainer>
                        ) : <div className="flex items-center justify-center h-full text-gray-500">Aucune dépense sur cette période.</div>}
                    </div>
                </div>
                <div className="lg:col-span-1">
                    <Challenges />
                </div>
            </div>

            <div className="mt-8">
                <ExpenseAnalyzer transactions={filteredTransactions} />
            </div>
        </div>
    );
};

const CustomizedContent = (props: any) => {
    const { depth, x, y, width, height, index, colors, name } = props;
    return (
      <g>
        <rect x={x} y={y} width={width} height={height} style={{ fill: colors[index % colors.length], stroke: '#111827', strokeWidth: 2 }} />
        {width > 80 && height > 30 && (
          <text x={x + width / 2} y={y + height / 2 + 7} textAnchor="middle" fill="#fff" fontSize={14}>{name}</text>
        )}
      </g>
    );
};

export default Cockpit;