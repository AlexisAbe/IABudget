import React, { useState, useContext, useEffect } from 'react';
import { UserContext } from '../../context/UserContext';
import { Transaction, ActionItem } from '../../types';
import { findRelevantTransactions } from '../../services/geminiService';

interface ActionableInsightModalProps {
    isOpen: boolean;
    onClose: () => void;
    insightTitle: string;
    insightDescription: string;
    potentialSaving: number;
}

const ActionableInsightModal: React.FC<ActionableInsightModalProps> = ({ isOpen, onClose, insightTitle, insightDescription, potentialSaving }) => {
    const context = useContext(UserContext);
    const [isLoading, setIsLoading] = useState(false);
    const [relevantTransactions, setRelevantTransactions] = useState<Transaction[]>([]);
    const [error, setError] = useState('');
    const [view, setView] = useState<'details' | 'form'>('details');
    const [actionType, setActionType] = useState<'reduce' | 'eliminate'>('reduce');

    useEffect(() => {
        if (isOpen && context?.transactions) {
            const fetchTransactions = async () => {
                setIsLoading(true);
                setError('');
                setRelevantTransactions([]);
                try {
                    const ids = await findRelevantTransactions(context.transactions, insightTitle, insightDescription);
                    const foundTransactions = context.transactions.filter(t => ids.includes(t.id));
                    setRelevantTransactions(foundTransactions);
                    if (foundTransactions.length === 0) {
                        setError("L'IA n'a pas trouvé de transactions spécifiques pour cette suggestion.");
                    }
                } catch (e) {
                    setError("Erreur lors de la recherche des transactions.");
                    console.error(e);
                } finally {
                    setIsLoading(false);
                }
            };
            fetchTransactions();
        }
    }, [isOpen, insightTitle, insightDescription, context?.transactions]);

    const handleCreateActionItem = () => {
        if (!context) return;
        const newActionItem: Omit<ActionItem, 'id' | 'status'> = {
            title: insightTitle,
            description: insightDescription,
            potentialSaving,
            relatedTransactions: relevantTransactions.map(t => ({
                transactionId: t.id,
                status: 'none'
            })),
            actionType,
        };
        context.addActionItem(newActionItem);
        handleClose();
    };
    
    const handleClose = () => {
        setView('details');
        onClose();
    };

    if (!isOpen || !context) return null;

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
            <div className="bg-gray-800 rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col border border-gray-700">
                <div className="p-6 border-b border-gray-700">
                    <h2 className="text-2xl font-bold text-white">{insightTitle}</h2>
                    <p className="text-sm text-gray-400">{insightDescription}</p>
                </div>

                <div className="p-6 overflow-y-auto space-y-4">
                   {view === 'details' && (
                       <>
                           <h3 className="font-semibold text-lg text-white">Transactions Liées</h3>
                           {isLoading && <div className="text-center text-gray-400">Recherche IA en cours...</div>}
                           {error && <p className="text-yellow-400 text-center">{error}</p>}
                           {!isLoading && relevantTransactions.length > 0 && (
                               <div className="space-y-2">
                                   {relevantTransactions.map(t => (
                                       <div key={t.id} className="flex justify-between items-center bg-gray-700/50 p-3 rounded-lg">
                                           <div>
                                               <p className="font-medium text-white">{t.description}</p>
                                               <p className="text-sm text-gray-400">{new Date(t.date).toLocaleDateString()}</p>
                                           </div>
                                           <p className="font-mono text-red-400">-{t.amount.toFixed(2)}€</p>
                                       </div>
                                   ))}
                               </div>
                           )}
                       </>
                   )}
                   {view === 'form' && (
                       <div>
                           <h3 className="font-semibold text-lg text-white mb-3">Créer un point d'action</h3>
                           <p className="text-gray-400 text-sm mb-4">Cette action sera ajoutée à votre "Plan d'Action" pour suivi.</p>
                           <div className="space-y-3">
                               <div>
                                   <label className="text-gray-300 font-medium">Objectif</label>
                                   <div className="flex gap-3 mt-2">
                                        <button onClick={() => setActionType('reduce')} className={`w-full p-2 rounded-lg border-2 ${actionType === 'reduce' ? 'border-indigo-500 bg-indigo-900/50' : 'border-gray-600'}`}>Réduire</button>
                                        <button onClick={() => setActionType('eliminate')} className={`w-full p-2 rounded-lg border-2 ${actionType === 'eliminate' ? 'border-red-500 bg-red-900/50' : 'border-gray-600'}`}>Éliminer</button>
                                   </div>
                               </div>
                           </div>
                       </div>
                   )}
                </div>

                <div className="p-6 mt-auto border-t border-gray-700 flex justify-end gap-3 bg-gray-800/50 rounded-b-2xl">
                    <button onClick={handleClose} className="bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-6 rounded-lg transition-colors">Fermer</button>
                     {view === 'details' && (
                        <button onClick={() => setView('form')} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-6 rounded-lg transition-colors">
                            Créer un point d'action
                        </button>
                    )}
                    {view === 'form' && (
                        <button onClick={handleCreateActionItem} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition-colors">
                            Ajouter au plan
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ActionableInsightModal;